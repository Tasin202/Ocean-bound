# Maritime Simulator (Godot 4.3, Android)

## Build the APK
1. Create a GitHub repo named `maritime-simulator` (or change `UPDATE_REPO` in `scripts/data.gd`).
2. Upload everything in this folder (`project.godot` must be at the repo root), including `.github/workflows/build.yml`.
3. Open the Actions tab -> "Build Android APK" -> the APK is in the run artifacts.
4. Release + update checker: push a tag such as `v1.0.1`. The workflow attaches the APK to a GitHub release, and the in-game
   "Check for updates" button (and the automatic check at start) compares the newest tag to `VERSION` in `scripts/data.gd`.
   Bump `VERSION` before tagging.

## Multiplayer server
`godot --headless --path . -- --server` (UDP 24565). Players enter the server address under Multiplayer.

## Controls
Walking: left stick moves, drag right side to look, prompt button interacts (doors, lift, helm, kiosks, boarding).
Helm: wheel (bottom-left), engine telegraph lever (bottom-right), buttons on the right, sail trim slider on sailboats.
