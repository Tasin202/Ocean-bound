extends CanvasLayer
# In-game HUD. Walking mode and helm mode never show at the same time.

const Display = preload("res://scripts/display.gd")
var main = null
var root = null
var mode = "none"
var touches = {}
var move_vec = Vector2.ZERO
var wheel_ctrl = null
var lever_ctrl = null
var stick_ctrl = null
var stick_origin = Vector2.ZERO
var stick_pos = Vector2.ZERO
var stick_on = false
var wheel_ang = 0.0
var walk_nodes = []
var helm_nodes = []
var top_lbl = null
var info_lbl = null
var toast_lbl = null
var warn_lbl = null
var prompt_btn = null
var trim_box = null
var trim_slider = null
var trim_lbl = null
var radar_panel = null
var radar_disp = null
var ap_panel = null
var ap_lbl = null
var instr = null
var toast_t = 0.0
var btns = {}


func _ready():
	layer = 5
	root = Control.new()
	root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(root)
	instr = Display.new()
	instr.mode = "instr"
	top_lbl = _label(Control.PRESET_TOP_LEFT, 12, 8, 700, 30, 20)
	info_lbl = _label(Control.PRESET_TOP_LEFT, 12, 44, 330, 170, 15)
	toast_lbl = _label(Control.PRESET_CENTER_TOP, -300, 90, 600, 40, 22)
	toast_lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	warn_lbl = _label(Control.PRESET_CENTER_TOP, -250, 140, 500, 30, 20)
	warn_lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	warn_lbl.add_theme_color_override("font_color", Color(1, 0.35, 0.3))
	prompt_btn = _btn("", 0.5, 0.78, -150, 0, 300, 70, func(): main.interact(), null)
	prompt_btn.visible = false
	# walk controls
	stick_ctrl = Control.new()
	_place(stick_ctrl, 0, 1, 20, -270, 250, 250)
	stick_ctrl.mouse_filter = Control.MOUSE_FILTER_IGNORE
	stick_ctrl.draw.connect(_draw_stick)
	root.add_child(stick_ctrl)
	walk_nodes.append(stick_ctrl)
	var bw = [["Camera", func(): main.cycle_cam()], ["Menu", func(): main.open_pause()]]
	for i in range(2):
		walk_nodes.append(_btn(bw[i][0], 1, 0, -150, 60 + i * 66, 140, 56, bw[i][1], null))
	# helm controls
	wheel_ctrl = Control.new()
	_place(wheel_ctrl, 0, 1, 20, -290, 270, 270)
	wheel_ctrl.mouse_filter = Control.MOUSE_FILTER_IGNORE
	wheel_ctrl.draw.connect(_draw_wheel)
	root.add_child(wheel_ctrl)
	helm_nodes.append(wheel_ctrl)
	lever_ctrl = Control.new()
	_place(lever_ctrl, 1, 1, -110, -340, 90, 320)
	lever_ctrl.mouse_filter = Control.MOUSE_FILTER_IGNORE
	lever_ctrl.draw.connect(_draw_lever)
	root.add_child(lever_ctrl)
	helm_nodes.append(lever_ctrl)
	var hb = [["Camera", func(): main.cycle_cam()], ["Map", func(): main.open_map()], ["Radar", func(): radar_panel.visible = not radar_panel.visible], ["Autopilot", func(): ap_panel.visible = not ap_panel.visible],
		["Anchor", func(): main.toggle_anchor()], ["Lights", func(): main.ship().lights_on = not main.ship().lights_on], ["Horn", func(): Sfx.play("horn", 3.0)], ["Moor", func(): main.toggle_moor()],
		["Port", func(): main.open_port(main.ship().moor_port)], ["Walk", func(): main.leave_helm()], ["Menu", func(): main.open_pause()]]
	for i in range(hb.size()):
		var b = _btn(hb[i][0], 1, 0, -300 + (i % 2) * 145, 50 + int(i / 2) * 60, 138, 52, hb[i][1], null)
		helm_nodes.append(b)
		btns[hb[i][0]] = b
	trim_box = VBoxContainer.new()
	_place(trim_box, 0.5, 1, -170, -92, 340, 80)
	trim_lbl = Label.new()
	trim_lbl.add_theme_font_size_override("font_size", 16)
	trim_box.add_child(trim_lbl)
	trim_slider = HSlider.new()
	trim_slider.min_value = 0.0
	trim_slider.max_value = 1.0
	trim_slider.step = 0.01
	trim_slider.custom_minimum_size = Vector2(300, 40)
	trim_slider.value_changed.connect(func(v): main.ship().sail_trim = v)
	trim_box.add_child(trim_slider)
	root.add_child(trim_box)
	helm_nodes.append(trim_box)
	_build_radar()
	_build_ap()
	set_mode("none")


func _place(c, ax, ay, ox, oy, w, h):
	c.anchor_left = ax
	c.anchor_right = ax
	c.anchor_top = ay
	c.anchor_bottom = ay
	c.offset_left = ox
	c.offset_top = oy
	c.offset_right = ox + w
	c.offset_bottom = oy + h


func _label(preset, x, y, w, h, fs):
	var l = Label.new()
	l.set_anchors_preset(preset)
	l.offset_left = x
	l.offset_top = y
	l.offset_right = x + w
	l.offset_bottom = y + h
	l.add_theme_font_size_override("font_size", fs)
	l.add_theme_color_override("font_outline_color", Color(0, 0, 0))
	l.add_theme_constant_override("outline_size", 5)
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(l)
	return l


func _btn(text, ax, ay, ox, oy, w, h, cb, group):
	var b = Button.new()
	b.text = text
	_place(b, ax, ay, ox, oy, w, h)
	b.add_theme_font_size_override("font_size", 19)
	b.pressed.connect(func():
		Sfx.play("click")
		cb.call())
	root.add_child(b)
	return b


func _build_radar():
	radar_panel = PanelContainer.new()
	_place(radar_panel, 0.5, 0, -175, 52, 350, 420)
	var vb = VBoxContainer.new()
	radar_panel.add_child(vb)
	radar_disp = Display.new()
	radar_disp.mode = "radar"
	radar_disp.interactive = true
	radar_disp.custom_minimum_size = Vector2(330, 330)
	vb.add_child(radar_disp)
	var row = HBoxContainer.new()
	vb.add_child(row)
	var defs = [["Rng-", _rng_dn], ["Rng+", _rng_up], ["Bright", _bright], ["N/H", _nh], ["X", _close_radar]]
	for d in defs:
		var b = Button.new()
		b.text = d[0]
		b.custom_minimum_size = Vector2(62, 44)
		var cb = d[1]
		b.pressed.connect(func():
			Sfx.play("click")
			cb.call())
		row.add_child(b)
	root.add_child(radar_panel)
	radar_panel.visible = false


func _build_ap():
	ap_panel = PanelContainer.new()
	_place(ap_panel, 0.5, 0.5, -190, -150, 380, 250)
	var vb = VBoxContainer.new()
	ap_panel.add_child(vb)
	ap_lbl = Label.new()
	ap_lbl.add_theme_font_size_override("font_size", 20)
	vb.add_child(ap_lbl)
	var row = HBoxContainer.new()
	vb.add_child(row)
	for d in [-10, -1, 1, 10]:
		var b = Button.new()
		b.text = "%+d" % d
		b.custom_minimum_size = Vector2(80, 50)
		var dd = d
		b.pressed.connect(func():
			var s = main.ship()
			if s.autopilot != 1:
				s.ap_heading = s.heading
			s.autopilot = 1
			s.ap_heading = wrapf(s.ap_heading + deg_to_rad(dd), -PI, PI))
		row.add_child(b)
	var defs = [["Hold current heading", _ap_hold], ["Choose destination (map)", _ap_map], ["Autopilot OFF", _ap_off], ["Close", _ap_close]]
	for d in defs:
		var b = Button.new()
		b.text = d[0]
		b.custom_minimum_size = Vector2(0, 44)
		var cb = d[1]
		b.pressed.connect(func():
			Sfx.play("click")
			cb.call())
		vb.add_child(b)
	root.add_child(ap_panel)
	ap_panel.visible = false


func set_mode(m):
	mode = m
	for n in walk_nodes:
		n.visible = (m == "walk")
	for n in helm_nodes:
		n.visible = (m == "helm")
	if m != "helm":
		radar_panel.visible = false
		ap_panel.visible = false
	top_lbl.visible = m != "none"
	info_lbl.visible = (m == "helm")
	touches.clear()
	move_vec = Vector2.ZERO
	stick_on = false
	prompt_btn.visible = false


func show_toast(t):
	toast_lbl.text = t
	toast_t = 3.5


func set_prompt(t):
	prompt_btn.visible = t != "" and mode == "walk"
	prompt_btn.text = t


func refresh(ship):
	var gd = GameData
	var hh = int(gd.time_h)
	top_lbl.text = "$%s    %02d:%02d    %s    wind %d kn" % [_fmt(gd.money), hh, int((gd.time_h - hh) * 60), gd.WEATHER_NAMES[gd.weather], int(gd.wind_speed * 1.944)]
	if toast_t > 0.0:
		toast_t -= get_process_delta_time()
		toast_lbl.modulate.a = clampf(toast_t, 0.0, 1.0)
	else:
		toast_lbl.text = ""
	if mode != "helm" or ship == null:
		return
	instr.ship = ship
	var lines = instr.instrument_lines()
	var p = ship.can_moor()
	var dest = ""
	if ship.autopilot == 2 and ship.route.size() > 0:
		var dl = ship.route[ship.route.size() - 1].distance_to(ship.pos2)
		dest = "\nROUTE %d m  ETA %d s" % [dl, int(dl / maxf(absf(ship.speed), ship.vmax() * 0.6))]
	info_lbl.text = "\n".join(lines) + dest
	radar_disp.ship = ship
	var ws = []
	if ship.fuel <= 0.0 and ship.spec.kind != "sail":
		ws.append("OUT OF FUEL")
	elif ship.fuel < ship.fuel_cap() * 0.1:
		ws.append("LOW FUEL")
	if ship.anchor:
		ws.append("ANCHOR DOWN")
	if ship.grounded:
		ws.append("AGROUND")
	if ship.damage > 50.0:
		ws.append("HEAVY DAMAGE")
	if main.collision_alert:
		ws.append("COLLISION RISK")
	warn_lbl.text = "  |  ".join(ws)
	btns["Moor"].text = "Cast off" if ship.moored else "Moor"
	btns["Moor"].disabled = not ship.moored and p < 0
	btns["Port"].disabled = not ship.moored
	btns["Anchor"].text = "Raise anchor" if ship.anchor else "Anchor"
	trim_box.visible = ship.spec.kind == "sail"
	if ship.spec.kind == "sail":
		trim_lbl.text = "Sail trim (ideal %d%%)" % int(ship.ideal_trim() * 100.0)
		trim_slider.set_value_no_signal(ship.sail_trim)
	ap_lbl.text = ["Autopilot OFF", "HDG HOLD %03d" % (int(rad_to_deg(ship.ap_heading) + 360.0) % 360), "ROUTE FOLLOWING"][ship.autopilot]
	var held = false
	for t in touches.values():
		if t.role == "wheel":
			held = true
	if not held:
		wheel_ang = lerpf(wheel_ang, ship.rudder * 2.1, 0.3)
	wheel_ctrl.queue_redraw()
	lever_ctrl.queue_redraw()


func _fmt(n):
	var s = str(int(n))
	var o = ""
	while s.length() > 3:
		o = "," + s.substr(s.length() - 3) + o
		s = s.substr(0, s.length() - 3)
	return s + o


func _draw_stick():
	if mode != "walk":
		return
	var c = Vector2(125, 125)
	stick_ctrl.draw_arc(c, 90, 0, TAU, 40, Color(1, 1, 1, 0.35), 3.0)
	var k = c + (move_vec * 70.0)
	stick_ctrl.draw_circle(k, 36, Color(1, 1, 1, 0.45))


func _draw_wheel():
	var c = Vector2(135, 135)
	var s = main.ship() if main else null
	var a = wheel_ang
	wheel_ctrl.draw_circle(c, 110, Color(0.05, 0.1, 0.16, 0.5))
	wheel_ctrl.draw_arc(c, 105, 0, TAU, 48, Color("c9a227"), 8.0)
	for i in range(6):
		var v = Vector2(sin(a + i * PI / 3.0), -cos(a + i * PI / 3.0))
		wheel_ctrl.draw_line(c - v * 100.0, c + v * 100.0 if i < 3 else c, Color("c9a227"), 5.0)
	wheel_ctrl.draw_circle(c, 18, Color("8b6b43"))
	wheel_ctrl.draw_line(c + Vector2(0, -112), c + Vector2(0, -92), Color(1, 0.3, 0.3), 5.0)


func _draw_lever():
	var h = 320.0
	lever_ctrl.draw_rect(Rect2(36, 10, 18, h - 20), Color(0.05, 0.1, 0.16, 0.6))
	var y0 = 10.0 + (h - 20.0) * (1.0 - (0.4 / 1.4))
	lever_ctrl.draw_line(Vector2(20, y0), Vector2(70, y0), Color(1, 1, 1, 0.6), 2.0)
	var sh = main.ship() if main else null
	var th = sh.throttle if sh else 0.0
	var y = 10.0 + (h - 20.0) * (1.0 - (th + 0.4) / 1.4)
	lever_ctrl.draw_rect(Rect2(14, y - 14, 62, 28), Color("e9b44c") if th >= 0 else Color("e57373"))


func _role(p):
	var sz = get_viewport().get_visible_rect().size
	if mode == "helm":
		if wheel_ctrl.get_global_rect().has_point(p):
			return "wheel"
		if lever_ctrl.get_global_rect().grow(20).has_point(p):
			return "lever"
		if radar_panel.visible and radar_panel.get_global_rect().has_point(p):
			return ""
		if ap_panel.visible and ap_panel.get_global_rect().has_point(p):
			return ""
		if p.x > sz.x * 0.25 and p.x < sz.x * 0.62 and p.y > sz.y * 0.1 and p.y < sz.y * 0.62:
			return "look"
	elif mode == "walk":
		if p.x < sz.x * 0.36 and p.y > sz.y * 0.4:
			return "stick"
		if p.x > sz.x * 0.38 and p.x < sz.x * 0.86 and p.y > sz.y * 0.08 and p.y < sz.y * 0.85:
			return "look"
	return ""


func _input(ev):
	if mode == "none" or main == null or main.ui_open:
		return
	if ev is InputEventScreenTouch:
		if ev.pressed:
			var r = _role(ev.position)
			if r != "":
				touches[ev.index] = {"role": r, "last": ev.position, "start": ev.position}
				if r == "stick":
					stick_origin = stick_ctrl.get_global_rect().get_center()
				elif r == "wheel":
					_wheel_drag(ev.index, ev.position, true)
				elif r == "lever":
					_lever(ev.position)
		elif touches.has(ev.index):
			if touches[ev.index].role == "stick":
				move_vec = Vector2.ZERO
				stick_ctrl.queue_redraw()
			touches.erase(ev.index)
	elif ev is InputEventScreenDrag and touches.has(ev.index):
		var t = touches[ev.index]
		match t.role:
			"stick":
				move_vec = ((ev.position - stick_origin) / 70.0).limit_length(1.0)
				stick_ctrl.queue_redraw()
			"look":
				main.look_delta(ev.relative.x, ev.relative.y)
			"wheel":
				_wheel_drag(ev.index, ev.position, false)
			"lever":
				_lever(ev.position)
		t.last = ev.position


func _wheel_drag(idx, p, start):
	var c = wheel_ctrl.get_global_rect().get_center()
	var a = atan2(p.x - c.x, -(p.y - c.y))
	var t = touches[idx]
	if start:
		t["a0"] = a
		t["w0"] = wheel_ang
	else:
		wheel_ang = clampf(t.w0 + wrapf(a - t.a0, -PI, PI) * GameData.settings.sens, -2.1, 2.1)
		var s = main.ship()
		s.rudder = wheel_ang / 2.1
		if s.autopilot > 0:
			s.autopilot = 0
			show_toast("Autopilot disengaged - manual steering")


func _lever(p):
	var r = lever_ctrl.get_global_rect()
	var v = 1.0 - clampf((p.y - r.position.y - 10.0) / (r.size.y - 20.0), 0.0, 1.0)
	var th = v * 1.4 - 0.4
	if absf(th) < 0.06:
		th = 0.0
	main.ship().throttle = clampf(th, -0.4, 1.0)


func _rng_dn():
	main.ship().radar_idx = maxi(0, main.ship().radar_idx - 1)


func _rng_up():
	main.ship().radar_idx = mini(4, main.ship().radar_idx + 1)


func _bright():
	var s = main.ship()
	s.radar_bright = 0.25 if s.radar_bright >= 1.0 else s.radar_bright + 0.25


func _nh():
	main.ship().radar_north = not main.ship().radar_north


func _close_radar():
	radar_panel.visible = false


func _ap_hold():
	main.ship().ap_heading = main.ship().heading
	main.ship().autopilot = 1


func _ap_map():
	main.open_map()


func _ap_off():
	main.ship().autopilot = 0


func _ap_close():
	ap_panel.visible = false
