extends Node
# Multiplayer: dedicated server (godot --headless -- --server) validates and relays ship states.
# Clients simulate their own ship; the server clamps speed/teleports, keeps ships out of land and owns identity.

signal status(text)
signal chat(sender, text)

const PORT = 24565
var is_server = false
var online = false
var players = {}        # peer id -> {name, ship, x, z, h, v, paint, t}
var my_id = 0
var addr = "127.0.0.1"
var want_online = false
var retry = 0
var retry_t = 0.0
var conn_t = 0.0
var connecting = false
var send_t = 0.0
var tick_t = 0.0


func _ready():
	multiplayer.connected_to_server.connect(_on_connected)
	multiplayer.connection_failed.connect(_on_failed)
	multiplayer.server_disconnected.connect(_on_lost)
	multiplayer.peer_disconnected.connect(_on_peer_left)
	if "--server" in OS.get_cmdline_user_args():
		start_server()


func start_server():
	var peer = ENetMultiplayerPeer.new()
	var err = peer.create_server(PORT, 64)
	if err != OK:
		push_error("Server failed to start: %d" % err)
		return
	multiplayer.multiplayer_peer = peer
	is_server = true
	online = true
	print("Maritime server listening on UDP %d" % PORT)


func connect_to(a):
	addr = a
	want_online = true
	retry = 0
	_try_connect()


func _try_connect():
	var peer = ENetMultiplayerPeer.new()
	var err = peer.create_client(addr, PORT)
	if err != OK:
		status.emit("Cannot start connection (error %d)" % err)
		return
	multiplayer.multiplayer_peer = peer
	connecting = true
	conn_t = 0.0
	status.emit("Connecting to %s..." % addr)


func disconnect_server():
	want_online = false
	online = false
	connecting = false
	players.clear()
	if multiplayer.multiplayer_peer:
		multiplayer.multiplayer_peer.close()
		multiplayer.multiplayer_peer = null
	status.emit("Disconnected")


func _on_connected():
	online = true
	connecting = false
	retry = 0
	my_id = multiplayer.get_unique_id()
	status.emit("Connected")
	hello.rpc_id(1, GameData.settings.name)


func _on_failed():
	connecting = false
	online = false
	status.emit("Connection failed")
	_schedule_retry()


func _on_lost():
	online = false
	players.clear()
	status.emit("Connection lost - reconnecting...")
	_schedule_retry()


func _schedule_retry():
	if want_online and retry < 5:
		retry += 1
		retry_t = 3.0
	elif want_online:
		want_online = false
		status.emit("Could not reconnect. Check the server address and try again.")


func _on_peer_left(id):
	players.erase(id)


func _process(dt):
	if connecting:
		conn_t += dt
		if conn_t > 8.0:
			connecting = false
			if multiplayer.multiplayer_peer:
				multiplayer.multiplayer_peer.close()
				multiplayer.multiplayer_peer = null
			status.emit("Connection timed out")
			_schedule_retry()
	if retry_t > 0.0:
		retry_t -= dt
		if retry_t <= 0.0 and want_online:
			_try_connect()
	if is_server:
		tick_t += dt
		if tick_t > 0.1:
			tick_t = 0.0
			var snap = {}
			for id in players:
				var p = players[id]
				snap[id] = [p.x, p.z, p.h, p.v, p.ship, p.name, p.paint]
			if not snap.is_empty():
				snap_down.rpc(snap)
		return
	if online and GameData.main and GameData.active_ship and GameData.main.mp_ready():
		send_t += dt
		if send_t > 0.1:
			send_t = 0.0
			var s = GameData.active_ship
			state_up.rpc_id(1, s.pos2.x, s.pos2.y, s.heading, s.speed, s.spec.id, s.paint_html())


func send_chat(text):
	if online and not is_server:
		chat_up.rpc_id(1, text)


@rpc("any_peer", "call_remote", "reliable")
func hello(nm):
	if not is_server:
		return
	var id = multiplayer.get_remote_sender_id()
	nm = str(nm).strip_edges().substr(0, 16)
	if nm == "":
		nm = "Captain"
	for p in players.values():
		if p.name == nm:
			nm = nm + str(id % 100)
	players[id] = {"name": nm, "ship": "sloop", "x": 0.0, "z": 0.0, "h": 0.0, "v": 0.0, "paint": "ffffff", "t": Time.get_ticks_msec() / 1000.0}
	print("Player joined: %s (%d)" % [nm, id])
	chat_down.rpc("Server", "%s joined" % nm)


@rpc("any_peer", "call_remote", "unreliable_ordered")
func state_up(x, z, h, v, ship_id, paint):
	if not is_server:
		return
	var id = multiplayer.get_remote_sender_id()
	if not players.has(id) or not GameData.SHIPS.has(str(ship_id)):
		return
	var p = players[id]
	var now = Time.get_ticks_msec() / 1000.0
	var dt = maxf(now - p.t, 0.02)
	var spec = GameData.SHIPS[str(ship_id)]
	var np = Vector2(float(x), float(z))
	var old = Vector2(p.x, p.z)
	var first = p.x == 0.0 and p.z == 0.0
	var ok = absf(np.x) < GameData.WORLD_HALF and absf(np.y) < GameData.WORLD_HALF
	if not first and old.distance_to(np) > spec.vmax * 1.6 * dt + 6.0:
		ok = false
	for isl in GameData.ISLANDS:
		if np.distance_to(Vector2(isl.x, isl.z)) < isl.r * 0.9:
			ok = false
	if not ok:
		correct.rpc_id(id, p.x, p.z)
		return
	p.x = np.x
	p.z = np.y
	p.h = float(h)
	p.v = clampf(float(v), -spec.vmax, spec.vmax * 1.3)
	p.ship = str(ship_id)
	p.paint = str(paint).substr(0, 8)
	p.t = now


@rpc("authority", "call_remote", "reliable")
func correct(x, z):
	if GameData.main and GameData.active_ship and not (x == 0.0 and z == 0.0):
		GameData.main.net_correct(Vector2(x, z))


@rpc("authority", "call_remote", "unreliable_ordered")
func snap_down(data):
	players = {}
	for id in data:
		var d = data[id]
		players[int(id)] = {"x": d[0], "z": d[1], "h": d[2], "v": d[3], "ship": d[4], "name": d[5], "paint": d[6]}


@rpc("any_peer", "call_remote", "reliable")
func chat_up(text):
	if not is_server:
		return
	var id = multiplayer.get_remote_sender_id()
	if players.has(id):
		chat_down.rpc(players[id].name, str(text).substr(0, 120))


@rpc("authority", "call_remote", "reliable")
func chat_down(sender, text):
	chat.emit(sender, text)
