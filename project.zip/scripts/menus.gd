extends CanvasLayer
# Menus and full-screen panels, built in code with a navy/teal maritime theme.

const SB = preload("res://scripts/ship_builder.gd")
const ShipScript = preload("res://scripts/ship.gd")
const Display = preload("res://scripts/display.gd")
var main = null
var root = null
var holder = null
var theme_res = null
var preview_ship = null
var preview_vp = null
var sel_type = "sloop"
var sel_paint = 0
var sel_int = 0
var update_info = ""
var update_url = ""
var load_bar = null
var load_lbl = null
var load_tip = null
var chat_log = []
var fleet_sel = -1
var map_disp = null
var map_lbl = null


func _ready():
	layer = 20
	theme_res = Theme.new()
	var mk = func(col, border):
		var sb = StyleBoxFlat.new()
		sb.bg_color = col
		sb.set_corner_radius_all(10)
		sb.set_border_width_all(1)
		sb.border_color = border
		sb.content_margin_left = 12
		sb.content_margin_right = 12
		sb.content_margin_top = 8
		sb.content_margin_bottom = 8
		return sb
	theme_res.set_stylebox("normal", "Button", mk.call(Color(0.08, 0.2, 0.3, 0.95), Color(0.2, 0.7, 0.75)))
	theme_res.set_stylebox("hover", "Button", mk.call(Color(0.12, 0.3, 0.42, 0.95), Color(0.4, 0.9, 0.9)))
	theme_res.set_stylebox("pressed", "Button", mk.call(Color(0.2, 0.5, 0.6, 1), Color(1, 1, 1)))
	theme_res.set_stylebox("disabled", "Button", mk.call(Color(0.1, 0.12, 0.15, 0.8), Color(0.2, 0.2, 0.25)))
	theme_res.set_stylebox("panel", "PanelContainer", mk.call(Color(0.04, 0.1, 0.16, 0.94), Color(0.2, 0.6, 0.7)))
	theme_res.set_font_size("font_size", "Button", 22)
	theme_res.set_font_size("font_size", "Label", 20)
	theme_res.set_color("font_color", "Label", Color(0.92, 0.97, 1.0))
	theme_res.set_color("font_disabled_color", "Button", Color(0.5, 0.55, 0.6))
	root = Control.new()
	root.theme = theme_res
	root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(root)


func is_open():
	return holder != null and is_instance_valid(holder)


func close():
	if is_open():
		holder.queue_free()
	holder = null
	preview_ship = null
	if main:
		main.ui_open = false


func _screen(title, w, h, dim = true, closable = true):
	if is_open():
		holder.queue_free()
	preview_ship = null
	holder = Control.new()
	holder.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	root.add_child(holder)
	if dim:
		var cr = ColorRect.new()
		cr.color = Color(0.0, 0.03, 0.06, 0.78)
		cr.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
		holder.add_child(cr)
	var pc = PanelContainer.new()
	pc.set_anchors_preset(Control.PRESET_CENTER)
	pc.anchor_left = 0.5
	pc.anchor_right = 0.5
	pc.anchor_top = 0.5
	pc.anchor_bottom = 0.5
	pc.offset_left = -w * 0.5
	pc.offset_right = w * 0.5
	pc.offset_top = -h * 0.5
	pc.offset_bottom = h * 0.5
	holder.add_child(pc)
	var vb = VBoxContainer.new()
	vb.add_theme_constant_override("separation", 8)
	pc.add_child(vb)
	var hb = HBoxContainer.new()
	vb.add_child(hb)
	var t = Label.new()
	t.text = title
	t.add_theme_font_size_override("font_size", 30)
	t.add_theme_color_override("font_color", Color(0.45, 0.95, 0.9))
	t.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	hb.add_child(t)
	if closable:
		var x = Button.new()
		x.text = "Close"
		x.pressed.connect(func():
			Sfx.play("click")
			close())
		hb.add_child(x)
	main.ui_open = true
	return vb


func _b(parent, text, cb, w = 0):
	var b = Button.new()
	b.text = text
	b.custom_minimum_size = Vector2(w, 52)
	b.pressed.connect(func():
		Sfx.play("click")
		cb.call())
	parent.add_child(b)
	return b


func _l(parent, text, fs = 20, col = Color(0.92, 0.97, 1.0)):
	var l = Label.new()
	l.text = text
	l.add_theme_font_size_override("font_size", fs)
	l.add_theme_color_override("font_color", col)
	l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	parent.add_child(l)
	return l


func _scroll(parent, h):
	var sc = ScrollContainer.new()
	sc.custom_minimum_size = Vector2(0, h)
	sc.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	sc.size_flags_vertical = Control.SIZE_EXPAND_FILL
	parent.add_child(sc)
	var v = VBoxContainer.new()
	v.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	v.add_theme_constant_override("separation", 6)
	sc.add_child(v)
	return v


func _fmt(n):
	var s = str(int(absf(n)))
	var o = ""
	while s.length() > 3:
		o = "," + s.substr(s.length() - 3) + o
		s = s.substr(0, s.length() - 3)
	return ("-" if n < 0 else "") + s + o


# ---------------- loading ----------------
func loading(frac, text):
	if holder == null or load_bar == null or not is_instance_valid(load_bar):
		var vb = _screen("MARITIME SIMULATOR", 760, 330, false, false)
		_l(vb, "Version " + GameData.VERSION, 16, Color(0.6, 0.7, 0.8))
		load_lbl = _l(vb, "Loading...", 22)
		load_bar = ProgressBar.new()
		load_bar.custom_minimum_size = Vector2(0, 30)
		load_bar.max_value = 1.0
		vb.add_child(load_bar)
		load_tip = _l(vb, ["Tip: moor alongside the pier before opening the port office.", "Tip: radar targets are real ships - check CPA before crossing a lane.", "Tip: autopilot steers only. You still control the throttle.", "Tip: sailboats cannot sail directly into the wind.", "Tip: storms raise the waves and reduce radar range."][randi() % 5], 18, Color(0.7, 0.85, 0.95))
		main.ui_open = true
	load_bar.value = frac
	load_lbl.text = text


func loading_error(text):
	var vb = _screen("Loading problem", 760, 300, false, false)
	_l(vb, text, 20, Color(1, 0.6, 0.5))
	_b(vb, "Retry", func(): get_tree().reload_current_scene())


# ---------------- main menu ----------------
func main_menu():
	var vb = _screen("MARITIME SIMULATOR", 520, 560, false, false)
	_l(vb, "Version " + GameData.VERSION, 16, Color(0.6, 0.7, 0.8))
	if update_info != "":
		if update_url != "":
			var ub = _b(vb, update_info, func(): OS.shell_open(update_url))
			ub.add_theme_color_override("font_color", Color(1, 0.9, 0.4))
		else:
			_l(vb, update_info, 17, Color(1, 0.9, 0.5))
	var cont = _b(vb, "Continue", func(): main.continue_game())
	cont.disabled = not GameData.has_save()
	_b(vb, "New game", func(): main.new_game())
	_b(vb, "Multiplayer", func(): mp_menu())
	_b(vb, "Settings", func(): settings(true))
	_b(vb, "Check for updates", func(): main.check_updates(true))
	_b(vb, "Quit", func(): get_tree().quit())


func mp_menu():
	var vb = _screen("Multiplayer", 620, 470, true, true)
	_l(vb, "Join a real server. Start one with:  godot --headless --path . -- --server", 16, Color(0.7, 0.85, 0.95))
	var nm = LineEdit.new()
	nm.text = GameData.settings.name
	nm.placeholder_text = "Captain name"
	vb.add_child(nm)
	var ad = LineEdit.new()
	ad.text = Net.addr
	ad.placeholder_text = "Server address"
	vb.add_child(ad)
	var st = _l(vb, "Not connected")
	Net.status.connect(func(t):
		if is_instance_valid(st):
			st.text = t)
	_b(vb, "Connect", func():
		GameData.settings.name = nm.text
		Net.connect_to(ad.text))
	_b(vb, "Disconnect", func(): Net.disconnect_server())
	_b(vb, "Play (online ships appear once you are sailing)", func():
		close()
		if main.mode == "menu":
			if GameData.has_save():
				main.continue_game()
			else:
				main.new_game())


# ---------------- settings ----------------
func settings(from_menu = false):
	var vb = _screen("Settings", 700, 560, true, true)
	var sc = _scroll(vb, 440)
	_l(sc, "Graphics preset (adaptive resolution always on)")
	var row = HBoxContainer.new()
	sc.add_child(row)
	var names = ["Low", "Medium", "High", "Ultra"]
	for i in range(4):
		var idx = i
		var b = _b(row, names[i], func():
			GameData.settings.gfx = idx
			main.apply_graphics())
		b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	var sl = func(label, key, mn, mx):
		_l(sc, label)
		var s = HSlider.new()
		s.min_value = mn
		s.max_value = mx
		s.step = 0.05
		s.value = GameData.settings[key]
		s.custom_minimum_size = Vector2(0, 36)
		s.value_changed.connect(func(v):
			GameData.settings[key] = v
			Sfx.apply_master())
		sc.add_child(s)
	sl.call("Master volume", "master", 0.0, 1.0)
	sl.call("Effects volume", "sfx", 0.0, 1.0)
	sl.call("Steering / look sensitivity", "sens", 0.4, 2.0)
	sl.call("HUD scale", "hud", 0.7, 1.4)
	var sw = CheckButton.new()
	sw.text = "Swap control sides (left-handed)"
	sw.button_pressed = GameData.settings.swap
	sw.toggled.connect(func(v): GameData.settings.swap = v)
	sc.add_child(sw)
	_l(sc, "Occlusion culling uses Godot's built-in frustum culling plus visibility ranges (LOD) on interior and detail meshes.", 15, Color(0.6, 0.7, 0.8))


# ---------------- pause ----------------
func pause():
	var vb = _screen("Paused", 460, 560, true, true)
	_b(vb, "Resume", func(): close())
	_b(vb, "Save game", func():
		main.save()
		main.toast("Game saved"))
	_b(vb, "Fleet & upgrades", func(): fleet())
	_b(vb, "Economy", func(): economy())
	_b(vb, "Chat / quick messages", func(): chat())
	_b(vb, "Settings", func(): settings())
	_b(vb, "Save & main menu", func():
		main.save()
		main.to_menu())


func chat():
	var vb = _screen("Chat", 620, 480, true, true)
	var log = _scroll(vb, 260)
	for c in chat_log:
		_l(log, c, 16)
	if not Net.online:
		_l(vb, "Not connected to a server.", 16, Color(1, 0.7, 0.5))
	var row = HBoxContainer.new()
	vb.add_child(row)
	for q in ["Hello!", "Sailing to port", "Watch out!", "Need help", "Thanks"]:
		var qq = q
		var qb = _b(row, q, func(): Net.send_chat(qq))
		qb.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	var le = LineEdit.new()
	le.placeholder_text = "Type a message and press Enter"
	le.text_submitted.connect(func(t):
		Net.send_chat(t)
		le.text = "")
	vb.add_child(le)


# ---------------- economy / fleet ----------------
func economy():
	var vb = _screen("Economy", 700, 560, true, true)
	_l(vb, "Balance: $%s" % _fmt(GameData.money), 28, Color(0.5, 1, 0.6))
	_l(vb, "Total income $%s    Total expenses $%s    Contracts completed %d" % [_fmt(GameData.income_total), _fmt(GameData.expense_total), GameData.contracts_done], 17)
	var sc = _scroll(vb, 380)
	for t in GameData.tx_log:
		var a = int(t.amt)
		_l(sc, "%s%s   %s" % ["+" if a > 0 else "-", _fmt(absi(a)), t.txt], 17, Color(0.5, 1, 0.6) if a > 0 else Color(1, 0.6, 0.5))


func fleet():
	var vb = _screen("Fleet & upgrades", 900, 600, true, true)
	var hb = HBoxContainer.new()
	hb.size_flags_vertical = Control.SIZE_EXPAND_FILL
	vb.add_child(hb)
	var left = _scroll(hb, 460)
	left.custom_minimum_size = Vector2(340, 0)
	var right = _scroll(hb, 460)
	if GameData.owned.is_empty():
		_l(left, "You own no ships yet. Visit a shipyard dealership.")
	for i in range(GameData.owned.size()):
		var rec = GameData.owned[i]
		var idx = i
		var sp = GameData.SHIPS[rec.type]
		var act = int(rec.uid) == GameData.active_uid
		_b(left, "%s%s" % ["> " if act else "", sp.name], func():
			fleet_sel = idx
			fleet())
	if fleet_sel >= 0 and fleet_sel < GameData.owned.size():
		var rec = GameData.owned[fleet_sel]
		var sp = GameData.SHIPS[rec.type]
		_l(right, sp.name, 24, Color(0.45, 0.95, 0.9))
		_l(right, "Fuel %d%%   Damage %d%%   Upgrades: engine %d, hull %d, radar %d, tank %d" % [100.0 * rec.fuel / (sp.fuelcap * (1.0 + 0.3 * rec.upg.fuel)), rec.damage, rec.upg.engine, rec.upg.hull, rec.upg.radar, rec.upg.fuel], 16)
		if int(rec.uid) != GameData.active_uid:
			_b(right, "Crew transfer to this ship ($250)", func():
				close()
				main.switch_ship(fleet_sel))
		for k in ["engine", "hull", "radar", "fuel"]:
			var kk = k
			var lvl = int(rec.upg[k])
			var b = _b(right, "Upgrade %s (lv %d/3) - $%s" % [k, lvl, _fmt(GameData.upg_cost(sp, lvl))], func():
				main.upgrade_ship(fleet_sel, kk)
				fleet())
			b.disabled = lvl >= 3
		_l(right, "Repaint ($%s)" % _fmt(sp.price * 0.01 + 200))
		var row = HBoxContainer.new()
		right.add_child(row)
		for c in range(GameData.HULL_COLORS.size()):
			var ci = c
			var sb = Button.new()
			sb.custom_minimum_size = Vector2(52, 52)
			var stl = StyleBoxFlat.new()
			stl.bg_color = GameData.HULL_COLORS[c]
			stl.set_corner_radius_all(8)
			sb.add_theme_stylebox_override("normal", stl)
			sb.pressed.connect(func():
				main.repaint_ship(fleet_sel, ci)
				fleet())
			row.add_child(sb)


# ---------------- dealership ----------------
func dealer(port):
	var vb = _screen("Dealership - %s" % GameData.PORTS[port].name, 1100, 620, true, true)
	_l(vb, "Balance: $%s     (ships are delivered to your berth here)" % _fmt(GameData.money), 18, Color(0.5, 1, 0.6))
	var hb = HBoxContainer.new()
	hb.size_flags_vertical = Control.SIZE_EXPAND_FILL
	vb.add_child(hb)
	var left = _scroll(hb, 400)
	left.custom_minimum_size = Vector2(300, 0)
	for id in GameData.SHIP_ORDER:
		var sid = id
		_b(left, GameData.SHIPS[id].name, func():
			sel_type = sid
			_rebuild_preview()
			_dealer_details(port))
	var mid = VBoxContainer.new()
	mid.name = "mid"
	hb.add_child(mid)
	var svc = SubViewportContainer.new()
	svc.custom_minimum_size = Vector2(420, 300)
	svc.stretch = true
	mid.add_child(svc)
	preview_vp = SubViewport.new()
	preview_vp.size = Vector2i(420, 300)
	preview_vp.own_world_3d = true
	preview_vp.transparent_bg = false
	svc.add_child(preview_vp)
	var we = WorldEnvironment.new()
	var en = Environment.new()
	en.background_mode = Environment.BG_COLOR
	en.background_color = Color(0.05, 0.18, 0.28)
	en.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	en.ambient_light_color = Color(0.7, 0.8, 0.9)
	en.ambient_light_energy = 0.8
	we.environment = en
	preview_vp.add_child(we)
	var lt = DirectionalLight3D.new()
	lt.rotation_degrees = Vector3(-40, 30, 0)
	preview_vp.add_child(lt)
	var cam = Camera3D.new()
	cam.name = "cam"
	preview_vp.add_child(cam)
	var det = VBoxContainer.new()
	det.name = "det"
	det.custom_minimum_size = Vector2(320, 0)
	hb.add_child(det)
	_rebuild_preview()
	_dealer_details(port)


func _rebuild_preview():
	if preview_vp == null or not is_instance_valid(preview_vp):
		return
	if preview_ship and is_instance_valid(preview_ship):
		preview_ship.queue_free()
	var sp = GameData.SHIPS[sel_type]
	preview_ship = ShipScript.new()
	preview_ship.role = "preview"
	preview_vp.add_child(preview_ship)
	preview_ship.setup(sp, false, GameData.HULL_COLORS[sel_paint], sel_int)
	preview_ship.wake_node.visible = false
	var cam = preview_vp.get_node("cam")
	var d = sp.L * 1.1 + 6.0
	cam.position = Vector3(d * 0.8, sp.free + sp.L * 0.3 + 2.0, d)
	cam.look_at(Vector3(0, sp.free + 1.0, 0))
	cam.far = 2000.0


func _process(dt):
	if preview_ship and is_instance_valid(preview_ship):
		preview_ship.rotation.y += dt * 0.5
	if map_disp and is_instance_valid(map_disp) and map_lbl:
		var sh = main.ship()
		if map_disp.selected_port >= 0 and sh:
			var d = GameData.PD[map_disp.selected_port].mid.distance_to(sh.pos2)
			var rt = GameData.find_path(sh.pos2, GameData.PD[map_disp.selected_port].approach) if false else map_disp.route_preview
			var len = 0.0
			var prev = sh.pos2
			for w in rt:
				len += prev.distance_to(w)
				prev = w
			map_lbl.text = "%s - route %.1f km, direct %.1f km, ETA %d min %02d s at cruising speed" % [GameData.PORTS[map_disp.selected_port].name, len / 1000.0, d / 1000.0, int(len / (sh.vmax() * 0.8) / 60.0), int(len / (sh.vmax() * 0.8)) % 60]
		else:
			map_lbl.text = "Tap a port to select a destination. Drag to pan."


func _dealer_details(port):
	var det = holder.find_child("det", true, false)
	if det == null:
		return
	for c in det.get_children():
		c.queue_free()
	var sp = GameData.SHIPS[sel_type]
	_l(det, sp.name, 24, Color(0.45, 0.95, 0.9))
	var cap = ("%d passengers" % sp.pax) if sp.pax > 0 else ("%d %s cargo" % [sp.cargo, sp.unit])
	_l(det, "Length %d m  Beam %d m  Draft %.1f m\nSpeed %.0f kn   Capacity %s\nFuel tank %d L   Operating cost $%.1f/min\nRadar range %.1f km\nPrice $%s" % [sp.L, sp.B, sp.draft, sp.vmax * 1.944, cap, sp.fuelcap, sp.upkeep, sp.radar / 1000.0, _fmt(sp.price)], 17)
	_l(det, "Hull colour")
	var row = HBoxContainer.new()
	det.add_child(row)
	for c in range(GameData.HULL_COLORS.size()):
		var ci = c
		var sb = Button.new()
		sb.custom_minimum_size = Vector2(36, 36)
		var stl = StyleBoxFlat.new()
		stl.bg_color = GameData.HULL_COLORS[c]
		stl.set_corner_radius_all(6)
		sb.add_theme_stylebox_override("normal", stl)
		sb.pressed.connect(func():
			sel_paint = ci
			_rebuild_preview())
		row.add_child(sb)
	_l(det, "Interior palette")
	var row2 = HBoxContainer.new()
	det.add_child(row2)
	for c in range(GameData.INTERIOR_COLORS.size()):
		var ci2 = c
		var sb2 = Button.new()
		sb2.custom_minimum_size = Vector2(36, 36)
		var st2 = StyleBoxFlat.new()
		st2.bg_color = GameData.INTERIOR_COLORS[c]
		st2.set_corner_radius_all(6)
		sb2.add_theme_stylebox_override("normal", st2)
		sb2.pressed.connect(func(): sel_int = ci2)
		row2.add_child(sb2)
	var buy = _b(det, "Buy for $%s" % _fmt(sp.price), func():
		if main.buy_ship(sel_type, sel_paint, sel_int, port):
			close())
	buy.disabled = GameData.money < sp.price


# ---------------- port office ----------------
func port(pi):
	var ship = main.ship()
	var vb = _screen(GameData.PORTS[pi].name + " - " + GameData.PORTS[pi].tag, 900, 620, true, true)
	_l(vb, "Balance: $%s" % _fmt(GameData.money), 20, Color(0.5, 1, 0.6))
	if ship == null or not ship.moored or ship.moor_port != pi:
		_l(vb, "Moor your active ship alongside this pier to use services and contracts.", 18, Color(1, 0.8, 0.5))
		if GameData.PORTS[pi].yard:
			_b(vb, "Open dealership", func(): dealer(pi))
		_b(vb, "Fleet", func(): fleet())
		return
	var spec = ship.spec
	_l(vb, "%s   fuel %d%%   damage %d%%" % [spec.name, 100.0 * ship.fuel / ship.fuel_cap(), ship.damage], 18)
	var row = HBoxContainer.new()
	vb.add_child(row)
	var need = ship.fuel_cap() - ship.fuel
	_b(row, "Refuel ($%s)" % _fmt(need * 1.1), func():
		main.refuel()
		port(pi))
	_b(row, "Repair ($%s)" % _fmt(ship.damage * spec.price * 0.0006), func():
		main.repair()
		port(pi))
	if GameData.PORTS[pi].yard:
		_b(row, "Dealership", func(): dealer(pi))
	_b(row, "Fleet", func(): fleet())
	if not ship.cargo.is_empty():
		var c = ship.cargo
		_l(vb, "On board: %d %s to %s - reward $%s" % [c.amount, "passengers" if c.pax else spec.unit + " cargo", GameData.PORTS[c.to].name, _fmt(c.reward)], 19, Color(1, 0.9, 0.5))
		if int(c.to) == pi:
			_b(vb, "Unload / disembark and collect payment", func():
				main.complete_contract()
				port(pi))
	else:
		_l(vb, "Contracts available here (one at a time):", 20)
		var sc = _scroll(vb, 330)
		for c in GameData.make_contracts(pi, spec):
			var cc = c
			var km = GameData.PD[pi].mid.distance_to(GameData.PD[c.to].mid) / 1000.0
			_b(sc, "%s -> %s   %.1f km   %d %s   $%s" % [GameData.PORTS[pi].name, GameData.PORTS[c.to].name, km, c.amount, "pax" if c.pax else spec.unit, _fmt(c.reward)], func():
				main.accept_contract(cc)
				port(pi))


# ---------------- world map ----------------
func map_screen():
	var sh = main.ship()
	var vb = _screen("World map", 1120, 640, true, true)
	if sh == null:
		_l(vb, "You need an active ship to use navigation.")
		return
	map_disp = Display.new()
	map_disp.mode = "chart"
	map_disp.ship = sh
	map_disp.interactive = true
	map_disp.zoom = 3200.0
	map_disp.custom_minimum_size = Vector2(1080, 440)
	map_disp.size_flags_vertical = Control.SIZE_EXPAND_FILL
	vb.add_child(map_disp)
	map_lbl = _l(vb, "", 18, Color(1, 0.9, 0.5))
	var row = HBoxContainer.new()
	vb.add_child(row)
	_b(row, "Zoom +", func(): map_disp.zoom = maxf(600.0, map_disp.zoom * 0.7))
	_b(row, "Zoom -", func(): map_disp.zoom = minf(9000.0, map_disp.zoom * 1.4))
	_b(row, "Centre on ship", func(): map_disp.follow = true)
	_b(row, "Start autopilot route", func():
		if map_disp.selected_port >= 0:
			var pi = map_disp.selected_port
			close()
			main.set_route(pi))
