extends Node3D
# Builds and animates the world: ocean, islands, ports, sky, clouds, weather, day/night.

const SB = preload("res://scripts/ship_builder.gd")
const WAVES = [[0.3, 62.0, 0.55], [1.1, 33.0, 0.28], [-0.6, 17.0, 0.13], [2.0, 9.5, 0.05]]
const WEATHER = [
	{"amp": 0.45, "wind": 5.0, "fog": 0.0003, "rain": 0.0, "cover": 0.3},
	{"amp": 0.9, "wind": 9.0, "fog": 0.0004, "rain": 0.0, "cover": 0.5},
	{"amp": 1.2, "wind": 8.0, "fog": 0.0007, "rain": 0.0, "cover": 0.8},
	{"amp": 1.6, "wind": 11.0, "fog": 0.0012, "rain": 0.7, "cover": 0.9},
	{"amp": 3.0, "wind": 20.0, "fog": 0.0016, "rain": 1.0, "cover": 1.0},
	{"amp": 0.3, "wind": 3.0, "fog": 0.006, "rain": 0.0, "cover": 0.6},
]

var sea_amp = 0.5
var wtime = 0.0
var ocean_near = null
var ocean_far = null
var ocean_mat = null
var far_mat = null
var env = null
var sun = null
var sky_mat = null
var cloud_mat = null
var cloud_mesh = null
var rain_node = null
var win_mat = null
var night_lights = []
var cur = {"amp": 0.45, "wind": 5.0, "fog": 0.0003, "rain": 0.0, "cover": 0.3}
var next_w = 150.0
var lightning = 8.0
var flash = 0.0
var cloud_off = Vector2.ZERO
var dayf = 1.0
var subdiv = 140


func wave_h(p):
	var h = 0.0
	for w in WAVES:
		var d = Vector2(sin(w[0]), cos(w[0]))
		var k = TAU / w[1]
		h += w[2] * sea_amp * sin(k * d.dot(p) - sqrt(9.81 * k) * wtime)
	return h


func build(cb):
	cb.call(0.05, "Building sky and lighting...")
	await get_tree().process_frame
	_env()
	cb.call(0.12, "Computing sea depth map...")
	var tex = await _depth_tex()
	cb.call(0.3, "Creating ocean...")
	_ocean(tex)
	await get_tree().process_frame
	for i in range(GameData.ISLANDS.size()):
		cb.call(0.35 + 0.05 * i, "Raising island %d of %d..." % [i + 1, GameData.ISLANDS.size()])
		_island(i)
		await get_tree().process_frame
	for i in range(GameData.PORTS.size()):
		cb.call(0.75 + 0.02 * i, "Constructing %s..." % GameData.PORTS[i].name)
		_port(i)
		await get_tree().process_frame
	apply_quality()


func _env():
	env = Environment.new()
	env.background_mode = Environment.BG_SKY
	var sky = Sky.new()
	sky_mat = ProceduralSkyMaterial.new()
	sky.sky_material = sky_mat
	env.sky = sky
	env.ambient_light_source = Environment.AMBIENT_SOURCE_SKY
	env.reflected_light_source = Environment.REFLECTION_SOURCE_SKY
	env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	env.fog_enabled = true
	env.fog_density = 0.0003
	var we = WorldEnvironment.new()
	we.environment = env
	add_child(we)
	sun = DirectionalLight3D.new()
	sun.shadow_enabled = true
	sun.directional_shadow_max_distance = 150.0
	add_child(sun)
	rain_node = GPUParticles3D.new()
	var pm = ParticleProcessMaterial.new()
	pm.emission_shape = ParticleProcessMaterial.EMISSION_SHAPE_BOX
	pm.emission_box_extents = Vector3(25, 0.1, 25)
	pm.direction = Vector3(0, -1, 0)
	pm.spread = 3.0
	pm.initial_velocity_min = 16.0
	pm.initial_velocity_max = 20.0
	pm.gravity = Vector3(0, -10, 0)
	rain_node.process_material = pm
	var qm = BoxMesh.new()
	qm.size = Vector3(0.015, 0.6, 0.015)
	var rm = StandardMaterial3D.new()
	rm.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	rm.albedo_color = Color(0.75, 0.82, 0.9, 0.5)
	rm.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	qm.material = rm
	rain_node.draw_pass_1 = qm
	rain_node.amount = 1600
	rain_node.lifetime = 1.3
	rain_node.local_coords = false
	rain_node.visibility_aabb = AABB(Vector3(-40, -30, -40), Vector3(80, 60, 80))
	rain_node.emitting = true
	rain_node.visible = false
	add_child(rain_node)
	cloud_mat = ShaderMaterial.new()
	cloud_mat.shader = load("res://shaders/clouds.gdshader")
	cloud_mesh = MeshInstance3D.new()
	var pl = PlaneMesh.new()
	pl.size = Vector2(24000, 24000)
	cloud_mesh.mesh = pl
	cloud_mesh.material_override = cloud_mat
	cloud_mesh.position.y = 1400.0
	cloud_mesh.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(cloud_mesh)
	win_mat = SB.mat(Color(1.0, 0.85, 0.5), 0.5, 0.0, 0.0)


func _depth_tex():
	var n = 256
	var img = Image.create(n, n, false, Image.FORMAT_L8)
	for y in range(n):
		for x in range(n):
			var p = Vector2((x + 0.5) / n * 2.0 - 1.0, (y + 0.5) / n * 2.0 - 1.0) * GameData.WORLD_HALF
			var dm = 1e9
			for isl in GameData.ISLANDS:
				dm = minf(dm, p.distance_to(Vector2(isl.x, isl.z)) - isl.r)
			var v = clampf(dm / 600.0, 0.0, 1.0)
			img.set_pixel(x, y, Color(v, v, v))
		if y % 64 == 0:
			await get_tree().process_frame
	return ImageTexture.create_from_image(img)


func _ocean(tex):
	ocean_mat = ShaderMaterial.new()
	ocean_mat.shader = load("res://shaders/ocean.gdshader")
	ocean_mat.set_shader_parameter("depth_tex", tex)
	far_mat = ocean_mat.duplicate()
	far_mat.set_shader_parameter("amp", 0.0)
	ocean_near = MeshInstance3D.new()
	ocean_near.material_override = ocean_mat
	ocean_near.extra_cull_margin = 30.0
	ocean_near.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(ocean_near)
	ocean_far = MeshInstance3D.new()
	var pf = PlaneMesh.new()
	pf.size = Vector2(60000, 60000)
	pf.subdivide_width = 2
	pf.subdivide_depth = 2
	ocean_far.mesh = pf
	ocean_far.material_override = far_mat
	ocean_far.position.y = -0.4
	ocean_far.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(ocean_far)


func apply_quality():
	var q = GameData.settings.gfx
	subdiv = [90, 130, 180, 240][q]
	var pm = PlaneMesh.new()
	pm.size = Vector2(1600, 1600)
	pm.subdivide_width = subdiv
	pm.subdivide_depth = subdiv
	ocean_near.mesh = pm
	sun.shadow_enabled = q >= 1
	sun.directional_shadow_max_distance = [60.0, 120.0, 180.0, 260.0][q]
	get_viewport().msaa_3d = [Viewport.MSAA_DISABLED, Viewport.MSAA_DISABLED, Viewport.MSAA_2X, Viewport.MSAA_4X][q]
	rain_node.amount_ratio = 1.0


func _hfun(rel, c, R, H, noise, quays):
	var d = rel.length()
	if d > R * 1.05:
		return -6.0
	var n = noise.get_noise_2d(c.x + rel.x, c.y + rel.y)
	var base = H * pow(maxf(0.0, 1.0 - d / R), 0.85) * (0.75 + 0.5 * (n + 0.5))
	for q in quays:
		var t = smoothstep(40.0, 230.0, (c + rel).distance_to(q))
		base = lerpf(1.3, base, t)
	return maxf(base, 0.0) if d <= R else -1.0


func _island(idx):
	var isl = GameData.ISLANDS[idx]
	var c = Vector2(isl.x, isl.z)
	var R = isl.r
	var H = isl.h
	var noise = FastNoiseLite.new()
	noise.seed = 100 + idx
	noise.frequency = 0.006
	var quays = []
	for i in range(GameData.PORTS.size()):
		if GameData.PORTS[i].island == idx:
			quays.append(GameData.PD[i].quay)
	var res = 52
	var ext = R * 1.12
	var hs = []
	for j in range(res + 1):
		for i in range(res + 1):
			hs.append(_hfun(Vector2(-ext + 2.0 * ext * i / res, -ext + 2.0 * ext * j / res), c, R, H, noise, quays))
	var st = SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)
	st.set_smooth_group(0)
	for j in range(res):
		for i in range(res):
			var idxs = [[i, j], [i + 1, j], [i, j + 1], [i + 1, j], [i + 1, j + 1], [i, j + 1]]
			for p in idxs:
				var h = hs[p[1] * (res + 1) + p[0]]
				st.set_color(_col(h, H))
				st.add_vertex(Vector3(-ext + 2.0 * ext * p[0] / res, h, -ext + 2.0 * ext * p[1] / res))
	st.generate_normals()
	var mi = MeshInstance3D.new()
	mi.mesh = st.commit()
	var m = StandardMaterial3D.new()
	m.vertex_color_use_as_albedo = true
	m.roughness = 0.95
	m.cull_mode = BaseMaterial3D.CULL_DISABLED
	mi.material_override = m
	mi.position = Vector3(c.x, 0, c.y)
	add_child(mi)
	# trees
	var rng = RandomNumberGenerator.new()
	rng.seed = idx * 7 + 1
	var tr = []
	for k in range(260):
		var a = rng.randf() * TAU
		var d = sqrt(rng.randf()) * R * 0.95
		var rel = Vector2(cos(a), sin(a)) * d
		var h = _hfun(rel, c, R, H, noise, quays)
		var near = false
		for q in quays:
			if (c + rel).distance_to(q) < 90.0:
				near = true
		if h > 3.0 and h < H * 0.65 and not near:
			tr.append(Vector3(rel.x, h, rel.y))
		if tr.size() >= 150:
			break
	if tr.size() > 0:
		var mm = MultiMesh.new()
		mm.transform_format = MultiMesh.TRANSFORM_3D
		var cm = CylinderMesh.new()
		cm.top_radius = 0.0
		cm.bottom_radius = 2.6
		cm.height = 9.0
		cm.radial_segments = 6
		mm.mesh = cm
		mm.instance_count = tr.size()
		for k in range(tr.size()):
			var s = rng.randf_range(0.7, 1.4)
			mm.set_instance_transform(k, Transform3D(Basis().scaled(Vector3(s, s, s)), tr[k] + Vector3(0, 4.0 * s, 0)))
		var mmi = MultiMeshInstance3D.new()
		mmi.multimesh = mm
		mmi.material_override = SB.mat(Color("2d5a2a"), 0.9)
		mmi.visibility_range_end = 1800.0
		mmi.position = Vector3(c.x, 0, c.y)
		add_child(mmi)


func _col(h, H):
	if h < 1.6:
		return Color(0.86, 0.78, 0.55)
	if h < H * 0.6:
		return Color(0.25, 0.42, 0.2).lerp(Color(0.33, 0.45, 0.22), clampf(h / 30.0, 0.0, 1.0))
	return Color(0.45, 0.42, 0.4)


func _port(i):
	var d = GameData.PD[i]
	var data = GameData.PORTS[i]
	var root = Node3D.new()
	root.position = Vector3(d.quay.x, 0, d.quay.y)
	root.rotation.y = -d.yaw
	add_child(root)
	var body = StaticBody3D.new()
	root.add_child(body)
	var cx = {"ship": root, "body": body, "posts": [], "detail": true}
	SB.box(cx, Vector3(0, 1.0, 0), Vector3(70, 3.0, 50), SB.mat(Color("8a8d90"), 0.9), true)
	SB.box(cx, Vector3(0, 1.5, -185), Vector3(14, 2.0, 320), SB.mat(Color("6f7276"), 0.9), true)
	for k in range(16):
		SB.cyl(cx, Vector3(7.0, 3.0, -35 - k * 20), 0.35, 1.0, SB.mat(Color("222629")), false, 400.0)
		SB.cyl(cx, Vector3(-7.0, 3.0, -35 - k * 20), 0.35, 1.0, SB.mat(Color("222629")), false, 400.0)
	var rng = RandomNumberGenerator.new()
	rng.seed = i + 40
	for k in range(10):
		var hx = -30.0 + k * 6.5
		var hz = 34.0 + rng.randf() * 18.0
		var hh = rng.randf_range(4.0, 8.0)
		SB.box(cx, Vector3(hx, 1.3 + hh * 0.5, hz), Vector3(5, hh, 5), SB.mat(Color.from_hsv(rng.randf(), 0.15, 0.9), 0.8), true, Vector3.ZERO, 900.0)
		SB.box(cx, Vector3(hx, 1.3 + hh + 0.8, hz), Vector3(5.6, 1.6, 5.6), SB.mat(Color("8c3b2e"), 0.8), false, Vector3.ZERO, 900.0)
		var w = SB.box(cx, Vector3(hx, 1.3 + hh * 0.6, hz - 2.55), Vector3(2.0, 1.4, 0.1), win_mat, false, Vector3.ZERO, 500.0)
	SB.box(cx, Vector3(-22, 6.0, 12), Vector3(18, 9.0, 12), SB.mat(Color("7b8794"), 0.8), true, Vector3.ZERO, 900.0)
	SB.cyl(cx, Vector3(26, 8.0, -18), 2.0, 14.0, SB.mat(Color("f2f2f2")), true, 1500.0, 1.5)
	SB.cyl(cx, Vector3(26, 16.5, -18), 1.6, 3.0, SB.mat(Color(1, 0.9, 0.5), 0.3, 0.0, 2.0), false, 3000.0)
	for k in range(2):
		SB.cyl(cx, Vector3(-28 + k * 12, 6.0, 20), 4.5, 7.0, SB.mat(Color("d8d8d8"), 0.5, 0.3), true, 900.0)
	if data.tag in ["Container port", "Commercial port", "Bulk terminal"]:
		for s in [-1.0, 1.0]:
			SB.box(cx, Vector3(s * 10.0, 14.0, -16), Vector3(1.2, 24.0, 1.2), SB.mat(Color("c0392b")), true, Vector3.ZERO, 1500.0)
			SB.box(cx, Vector3(s * 10.0, 26.0, -26), Vector3(1.0, 1.0, 36.0), SB.mat(Color("c0392b")), false, Vector3.ZERO, 1500.0)
	var lamp_n = 0
	for z in [-20.0, -80.0, -140.0]:
		SB.cyl(cx, Vector3(-6.5, 6.0, z), 0.12, 7.0, SB.mat(Color("333")), false, 600.0)
		var l = OmniLight3D.new()
		l.position = Vector3(-6.5, 9.5, z)
		l.omni_range = 40.0
		l.light_energy = 1.4
		l.visible = false
		root.add_child(l)
		night_lights.append(l)
	var lab = Label3D.new()
	lab.text = data.name
	lab.font_size = 96
	lab.pixel_size = 0.05
	lab.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	lab.position = Vector3(0, 18, 4)
	lab.visibility_range_end = 1500.0
	lab.modulate = Color(1, 1, 1, 0.95)
	lab.outline_size = 18
	root.add_child(lab)
	GameData.make_interact(root, Vector3(-14, 3.2, 6), "Port office: services & contracts", Callable(GameData.main, "open_port").bind(i))
	SB.box(cx, Vector3(-14, 2.6, 6), Vector3(1.4, 2.2, 1.4), SB.mat(Color("2f8f5b"), 0.4, 0.0, 1.0), true)
	if data.yard:
		GameData.make_interact(root, Vector3(14, 3.2, 6), "Ship dealership", Callable(GameData.main, "open_dealer").bind(i))
		SB.box(cx, Vector3(14, 2.6, 6), Vector3(1.4, 2.2, 1.4), SB.mat(Color("e9b44c"), 0.4, 0.0, 1.0), true)
	for s in [-1.0, 1.0]:
		GameData.make_interact(root, Vector3(s * 6.0, 3.3, -185), "Board your ship", Callable(GameData.main, "board_at_port").bind(i, s))


func update(dt, cam_pos):
	wtime += dt
	GameData.time_h = fmod(GameData.time_h + dt / 60.0, 24.0)
	next_w -= dt
	if next_w <= 0.0:
		next_w = randf_range(120.0, 300.0)
		var r = randf()
		GameData.weather = 0 if r < 0.3 else (1 if r < 0.5 else (2 if r < 0.65 else (3 if r < 0.8 else (4 if r < 0.9 else 5))))
		GameData.wind_dir = wrapf(GameData.wind_dir + randf_range(-1.0, 1.0), -PI, PI)
	var tw = WEATHER[GameData.weather]
	for k in cur:
		cur[k] = lerpf(cur[k], tw[k], 1.0 - exp(-dt * 0.15))
	sea_amp = cur.amp
	GameData.wind_speed = cur.wind
	GameData.rain = cur.rain
	var t = GameData.time_h
	var el = sin((t - 6.0) / 24.0 * TAU)
	dayf = smoothstep(-0.12, 0.25, el)
	var warm = (1.0 - smoothstep(0.0, 0.35, absf(el))) if el > -0.15 else 0.0
	var grey = clampf(cur.cover * 0.8 + cur.rain * 0.2, 0.0, 1.0)
	var top = Color(0.01, 0.015, 0.05).lerp(Color(0.25, 0.45, 0.85), dayf).lerp(Color(0.45, 0.5, 0.56) * dayf + Color(0.02, 0.02, 0.03), grey * 0.7)
	var hor = Color(0.03, 0.04, 0.09).lerp(Color(0.65, 0.78, 0.92), dayf).lerp(Color(1.0, 0.55, 0.3), warm * 0.8).lerp(Color(0.55, 0.58, 0.62) * dayf + Color(0.03, 0.03, 0.04), grey * 0.7)
	sky_mat.sky_top_color = top
	sky_mat.sky_horizon_color = hor
	sky_mat.ground_horizon_color = hor
	sky_mat.ground_bottom_color = hor * 0.5
	sun.rotation_degrees = Vector3(-el * 70.0, -90.0 + (t - 12.0) * 15.0, 0)
	sun.light_energy = 1.2 * dayf * (1.0 - 0.6 * grey)
	sun.light_color = Color(1, 1, 1).lerp(Color(1.0, 0.7, 0.45), warm)
	sun.visible = dayf > 0.02
	flash = maxf(0.0, flash - dt * 5.0)
	env.ambient_light_energy = lerpf(0.25, 1.0, dayf) + flash * 3.0
	env.background_energy_multiplier = 1.0 + flash * 2.0
	env.fog_light_color = hor
	env.fog_density = cur.fog + (1.0 - dayf) * 0.0002
	if GameData.weather == 4:
		lightning -= dt
		if lightning <= 0.0:
			lightning = randf_range(5.0, 14.0)
			flash = 1.0
			var tt = get_tree().create_timer(randf_range(0.5, 3.0))
			tt.timeout.connect(func(): Sfx.play("thunder", 0.0, randf_range(0.8, 1.1)))
	ocean_mat.set_shader_parameter("amp", sea_amp)
	ocean_mat.set_shader_parameter("t", wtime)
	var dc = Color(0.003, 0.01, 0.025).lerp(Color(0.02, 0.10, 0.18), dayf)
	ocean_mat.set_shader_parameter("deep_col", dc)
	far_mat.set_shader_parameter("deep_col", dc)
	ocean_mat.set_shader_parameter("sky_col", hor)
	far_mat.set_shader_parameter("sky_col", hor)
	var step = 1600.0 / subdiv
	ocean_near.position = Vector3(snappedf(cam_pos.x, step), 0, snappedf(cam_pos.z, step))
	ocean_far.position.x = cam_pos.x
	ocean_far.position.z = cam_pos.z
	cloud_mesh.position.x = cam_pos.x
	cloud_mesh.position.z = cam_pos.z
	cloud_off += Vector2(sin(GameData.wind_dir), -cos(GameData.wind_dir)) * cur.wind * dt * 0.8
	cloud_mat.set_shader_parameter("offs", cloud_off)
	cloud_mat.set_shader_parameter("cover", cur.cover)
	cloud_mat.set_shader_parameter("lit_col", Color(1, 1, 1).lerp(Color(1.0, 0.65, 0.4), warm * 0.8) * (0.08 + 0.92 * dayf))
	cloud_mat.set_shader_parameter("shade_col", Color(0.55, 0.6, 0.7) * (0.05 + 0.95 * dayf) * (1.0 - 0.4 * grey))
	rain_node.visible = cur.rain > 0.03
	rain_node.amount_ratio = clampf(cur.rain, 0.05, 1.0)
	rain_node.global_position = cam_pos + Vector3(0, 10, 0)
	var night = dayf < 0.25
	for l in night_lights:
		l.visible = night
	win_mat.emission_enabled = night
	win_mat.emission = Color(1.0, 0.8, 0.45)
	win_mat.emission_energy_multiplier = 1.6
