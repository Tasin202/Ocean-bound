extends RefCounted
# Procedural ship models: lofted hulls, decks, walkable deckhouses, bridges, engine rooms, rigs.

static var _m = {}


static func mat(c, rough = 0.6, metal = 0.0, emit = 0.0, alpha = 1.0, dbl = false):
	var key = str([c.to_html(), rough, metal, emit, alpha, dbl])
	if _m.has(key):
		return _m[key]
	var m = StandardMaterial3D.new()
	m.albedo_color = Color(c.r, c.g, c.b, alpha)
	m.roughness = rough
	m.metallic = metal
	if emit > 0.0:
		m.emission_enabled = true
		m.emission = c
		m.emission_energy_multiplier = emit
	if alpha < 1.0:
		m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	if dbl:
		m.cull_mode = BaseMaterial3D.CULL_DISABLED
	_m[key] = m
	return m


static func box(cx, pos, size, m, collide = true, rot = Vector3.ZERO, lod = 0.0):
	var mi = MeshInstance3D.new()
	var bm = BoxMesh.new()
	bm.size = size
	mi.mesh = bm
	mi.material_override = m
	mi.position = pos
	mi.rotation = rot
	if lod > 0.0:
		mi.visibility_range_end = lod
	cx.ship.add_child(mi)
	if collide:
		var cs = CollisionShape3D.new()
		var sh = BoxShape3D.new()
		sh.size = size
		cs.shape = sh
		cs.position = pos
		cs.rotation = rot
		cx.body.add_child(cs)
	return mi


static func cyl(cx, pos, r, h, m, collide = false, lod = 0.0, rtop = -1.0, rot = Vector3.ZERO):
	var mi = MeshInstance3D.new()
	var cm = CylinderMesh.new()
	cm.bottom_radius = r
	cm.top_radius = r if rtop < 0.0 else rtop
	cm.height = h
	cm.radial_segments = 12
	cm.rings = 1
	mi.mesh = cm
	mi.material_override = m
	mi.position = pos
	mi.rotation = rot
	if lod > 0.0:
		mi.visibility_range_end = lod
	cx.ship.add_child(mi)
	if collide:
		var cs = CollisionShape3D.new()
		var sh = CylinderShape3D.new()
		sh.radius = r
		sh.height = h
		cs.shape = sh
		cs.position = pos
		cx.body.add_child(cs)
	return mi


static func omni(cx, pos, rng, en, col = Color(1.0, 0.95, 0.85)):
	var l = OmniLight3D.new()
	l.position = pos
	l.omni_range = rng
	l.light_energy = en
	l.light_color = col
	l.distance_fade_enabled = true
	l.distance_fade_begin = 40.0
	l.distance_fade_length = 25.0
	cx.ship.add_child(l)
	return l


static func halfw(u):
	if u < 0.28:
		return pow(sin(u / 0.28 * PI * 0.5), 0.75)
	if u < 0.82:
		return 1.0
	var q = (u - 0.82) / 0.18
	return 1.0 - 0.38 * q * q


static func depthf(u):
	var f = 0.35 + 0.65 * smoothstep(0.0, 0.4, u)
	if u > 0.85:
		f *= 1.0 - 0.15 * (u - 0.85) / 0.15
	return f


static func _tri(st, a, b, c):
	st.add_vertex(a)
	st.add_vertex(b)
	st.add_vertex(c)


static func hull(cx, L, B, draft, free, paint):
	var N = 22
	var M = 8
	var st = SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)
	st.set_smooth_group(0)
	var rings = []
	for i in range(N + 1):
		var u = float(i) / N
		var z = -L * 0.5 + u * L
		var hw = B * 0.5 * halfw(u)
		var dr = draft * depthf(u)
		var ring = []
		for k in range(M + 1):
			var s = float(k) / M
			ring.append(Vector3(-hw * sqrt(maxf(0.0, 1.0 - s * s * s)), free - s * (free + dr), z))
		for k in range(M - 1, -1, -1):
			var s2 = float(k) / M
			ring.append(Vector3(hw * sqrt(maxf(0.0, 1.0 - s2 * s2 * s2)), free - s2 * (free + dr), z))
		rings.append(ring)
	for i in range(N):
		for r in range(2 * M):
			var a = rings[i][r]
			var b = rings[i][r + 1]
			var c = rings[i + 1][r]
			var d = rings[i + 1][r + 1]
			_tri(st, a, c, b)
			_tri(st, b, c, d)
	st.set_smooth_group(-1)
	var last = rings[N]
	var cen = Vector3(0, (last[0].y + last[M].y) * 0.5, last[0].z)
	for r in range(2 * M):
		_tri(st, last[r], cen, last[r + 1])
	st.generate_normals()
	var mi = MeshInstance3D.new()
	mi.mesh = st.commit()
	var sm = ShaderMaterial.new()
	sm.shader = load("res://shaders/hull.gdshader")
	sm.set_shader_parameter("top_col", paint)
	sm.set_shader_parameter("bot_col", Color(0.42, 0.07, 0.05))
	mi.material_override = sm
	cx.ship.add_child(mi)


static func deck_part(cx, L, B, free, u0, u1, m):
	var n = 8
	var pts = []
	for i in range(n + 1):
		var u = lerpf(u0, u1, float(i) / n)
		pts.append(Vector2(-L * 0.5 + u * L, B * 0.5 * halfw(u)))
	var st = SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)
	var cp = PackedVector3Array()
	for i in range(n):
		var a = pts[i]
		var b = pts[i + 1]
		var v = [Vector3(-a.y, free, a.x), Vector3(a.y, free, a.x), Vector3(-b.y, free, b.x), Vector3(b.y, free, b.x)]
		for idx in [0, 1, 2, 1, 3, 2]:
			st.add_vertex(v[idx])
	for p in pts:
		cp.append(Vector3(-p.y, free, p.x))
		cp.append(Vector3(p.y, free, p.x))
		cp.append(Vector3(-p.y, free - 0.3, p.x))
		cp.append(Vector3(p.y, free - 0.3, p.x))
	st.generate_normals()
	var mi = MeshInstance3D.new()
	mi.mesh = st.commit()
	mi.material_override = m
	cx.ship.add_child(mi)
	var cs = CollisionShape3D.new()
	var sh = ConvexPolygonShape3D.new()
	sh.points = cp
	cs.shape = sh
	cx.body.add_child(cs)


static func rail(cx, a, b, h):
	var d = b - a
	var ln = d.length()
	if ln < 0.1:
		return
	var bs = Basis.looking_at(d.normalized(), Vector3.UP)
	var mid = (a + b) * 0.5
	var mi = MeshInstance3D.new()
	var bm = BoxMesh.new()
	bm.size = Vector3(0.06, 0.06, ln)
	mi.mesh = bm
	mi.material_override = mat(Color("c9ced3"), 0.4, 0.6)
	mi.transform = Transform3D(bs, mid + Vector3(0, h, 0))
	mi.visibility_range_end = 300.0
	cx.ship.add_child(mi)
	var cs = CollisionShape3D.new()
	var sh = BoxShape3D.new()
	sh.size = Vector3(0.12, h + 0.4, ln)
	cs.shape = sh
	cs.transform = Transform3D(bs, mid + Vector3(0, h * 0.5, 0))
	cx.body.add_child(cs)
	var n = int(ln / 2.0) + 1
	for i in range(n + 1):
		cx.posts.append(Transform3D(Basis().scaled(Vector3(1, h, 1)), a + d * (float(i) / n) + Vector3(0, h * 0.5, 0)))


static func finish_posts(cx):
	if cx.posts.is_empty():
		return
	var mm = MultiMesh.new()
	mm.transform_format = MultiMesh.TRANSFORM_3D
	var bm = BoxMesh.new()
	bm.size = Vector3(0.05, 1.0, 0.05)
	mm.mesh = bm
	mm.instance_count = cx.posts.size()
	for i in range(cx.posts.size()):
		mm.set_instance_transform(i, cx.posts[i])
	var mi = MultiMeshInstance3D.new()
	mi.multimesh = mm
	mi.material_override = mat(Color("c9ced3"), 0.4, 0.6)
	mi.visibility_range_end = 250.0
	cx.ship.add_child(mi)


static func hull_rails(cx, L, B, free, h):
	var left = []
	var right = []
	for i in range(23):
		var u = i / 22.0
		var hw = maxf(B * 0.5 * halfw(u) - 0.08, 0.0)
		left.append(Vector3(-hw, free, -L * 0.5 + u * L))
		right.append(Vector3(hw, free, -L * 0.5 + u * L))
	for i in range(22):
		rail(cx, left[i], left[i + 1], h)
		rail(cx, right[i], right[i + 1], h)
	rail(cx, left[22], right[22], h)


static func ramp(cx, a, b, w, m):
	var d = b - a
	var bs = Basis.looking_at(d.normalized(), Vector3.UP)
	var mid = (a + b) * 0.5
	var mi = box(cx, Vector3.ZERO, Vector3(w, 0.15, d.length()), m, false)
	mi.transform = Transform3D(bs, mid - bs.y * 0.075)
	var cs = CollisionShape3D.new()
	var sh = BoxShape3D.new()
	sh.size = Vector3(w, 0.15, d.length())
	cs.shape = sh
	cs.transform = mi.transform
	cx.body.add_child(cs)
	for i in range(7):
		var p = a.lerp(b, (i + 0.5) / 7.0)
		var st = box(cx, Vector3.ZERO, Vector3(w, 0.04, 0.12), mat(Color("222629")), false, Vector3.ZERO, 120.0)
		st.transform = Transform3D(bs, p + bs.y * 0.01)
	var h = 1.0
	var off = bs.x * (w * 0.5 - 0.05)
	rail(cx, a + off, b + off, h)
	rail(cx, a - off, b - off, h)


static func make_door(cx, hinge, w, h, along, m, sgn = 1.0):
	var pivot = Node3D.new()
	pivot.position = hinge
	cx.ship.add_child(pivot)
	var sz = Vector3(w, h, 0.07) if along.x != 0.0 else Vector3(0.07, h, w)
	var mi = MeshInstance3D.new()
	var bm = BoxMesh.new()
	bm.size = sz
	mi.mesh = bm
	mi.material_override = m
	mi.position = along * (w * 0.5) + Vector3(0, h * 0.5, 0)
	pivot.add_child(mi)
	var sb = StaticBody3D.new()
	var cs = CollisionShape3D.new()
	var sh = BoxShape3D.new()
	sh.size = sz
	cs.shape = sh
	cs.position = mi.position
	sb.add_child(cs)
	pivot.add_child(sb)
	var st = {"open": false}
	var act = func():
		st.open = not st.open
		var tw = pivot.create_tween()
		tw.tween_property(pivot, "rotation:y", (1.57 * sgn if st.open else 0.0), 0.4)
		Sfx.play("click", -6.0, 0.7)
	GameData.make_interact(cx.ship, hinge + along * (w * 0.5) + Vector3(0, 1.0, 0), "Open / close door", act)
	return pivot


static func _wbox(cx, axis, fixed, s0, s1, ya, hh, th, m, lod):
	var ln = s1 - s0
	if ln < 0.05 or hh < 0.05:
		return
	var c = (s0 + s1) * 0.5
	var pos = Vector3(fixed, ya + hh * 0.5, c) if axis == "x" else Vector3(c, ya + hh * 0.5, fixed)
	var sz = Vector3(th, hh, ln) if axis == "x" else Vector3(ln, hh, th)
	box(cx, pos, sz, m, true, Vector3.ZERO, lod)


static func wall_run(cx, axis, fixed, a0, a1, y0, h, doors, win, wm, gm, lod = 400.0):
	var cur = a0
	var segs = []
	var ds = doors.duplicate()
	ds.sort_custom(func(p, q): return p[0] < q[0])
	for d in ds:
		var d0 = d[0] - d[1] * 0.5
		var d1 = d[0] + d[1] * 0.5
		if d0 > cur:
			segs.append([cur, d0])
		cur = d1
		_wbox(cx, axis, fixed, d0, d1, y0 + 2.1, h - 2.1, 0.14, wm, lod)
	if cur < a1:
		segs.append([cur, a1])
	for s in segs:
		if win:
			_wbox(cx, axis, fixed, s[0], s[1], y0, 0.9, 0.14, wm, lod)
			_wbox(cx, axis, fixed, s[0], s[1], y0 + 0.9, 1.3, 0.06, gm, lod)
			_wbox(cx, axis, fixed, s[0], s[1], y0 + 2.2, h - 2.2, 0.14, wm, lod)
		else:
			_wbox(cx, axis, fixed, s[0], s[1], y0, h, 0.14, wm, lod)


static func interior(cx, zf, za, W, y0, k, ip, pitch, lobby):
	var half = W * 0.5
	var wm = mat(Color("d9d6cf"), 0.8)
	var wood = mat(Color("6b4a2f"), 0.7)
	var carpet = mat(GameData.INTERIOR_COLORS[ip], 0.95)
	box(cx, Vector3(0, y0 + 0.012, (zf + za) * 0.5), Vector3(W - 0.3, 0.025, za - zf - 0.3), carpet, false, Vector3.ZERO, 60.0)
	var z = zf + 3.0
	while z < za:
		omni(cx, Vector3(0, y0 + 2.5, z), 9.0, 0.9)
		z += 11.0
	var zc = zf + lobby + 0.3
	while zc + pitch <= za - 0.3:
		var zm = zc + pitch * 0.5
		for s in [-1.0, 1.0]:
			var xw = s * 0.9
			_wbox(cx, "x", xw, zc, zm - 0.45, y0, 2.7, 0.1, wm, 60.0)
			_wbox(cx, "x", xw, zm + 0.45, zc + pitch, y0, 2.7, 0.1, wm, 60.0)
			_wbox(cx, "x", xw, zm - 0.45, zm + 0.45, y0 + 2.1, 0.6, 0.1, wm, 60.0)
			make_door(cx, Vector3(xw, y0, zm - 0.45), 0.9, 2.1, Vector3(0, 0, 1), wood, s)
			box(cx, Vector3(s * (0.9 + (half - 0.9) * 0.5), y0 + 1.35, zc + pitch), Vector3(half - 1.0, 2.7, 0.12), wm, true, Vector3.ZERO, 60.0)
			box(cx, Vector3(s * (half - 0.9), y0 + 0.3, zm), Vector3(0.9, 0.5, 2.0), wood, true, Vector3.ZERO, 40.0)
			box(cx, Vector3(s * (half - 1.5), y0 + 0.4, zm + 1.8), Vector3(0.5, 0.8, 0.5), wood, true, Vector3.ZERO, 40.0)
		zc += pitch


static func saloon(cx, zf, za, W, y0, ip):
	var half = W * 0.5
	var seat = mat(GameData.INTERIOR_COLORS[ip].lightened(0.15), 0.9)
	box(cx, Vector3(0, y0 + 0.012, (zf + za) * 0.5), Vector3(W - 0.3, 0.025, za - zf - 0.3), mat(GameData.INTERIOR_COLORS[ip], 0.95), false, Vector3.ZERO, 60.0)
	var z = zf + 2.5
	while z < za - 5.0:
		omni(cx, Vector3(0, y0 + 2.5, z), 8.0, 0.9)
		for s in [-1.0, 1.0]:
			box(cx, Vector3(s * (half - 0.9), y0 + 0.35, z), Vector3(1.2, 0.7, 1.6), seat, true, Vector3.ZERO, 40.0)
			box(cx, Vector3(s * 1.5, y0 + 0.35, z), Vector3(1.2, 0.7, 1.6), seat, true, Vector3.ZERO, 40.0)
		z += 2.4


static func lift_and_engine(cx, ship, spec, zf, W, y0):
	var L = spec.L
	var B = spec.B
	var ye = maxf(-spec.draft + 0.8, -2.8)
	var half = W * 0.5
	var lm = mat(Color("2f8f5b"), 0.4, 0.3, 0.6)
	var lp = Vector3(-(half - 0.9), y0 + 1.1, zf + 1.4)
	box(cx, lp + Vector3(0, 0.15, 0), Vector3(1.4, 2.5, 1.4), mat(Color("9aa1a6"), 0.5, 0.5), true)
	box(cx, lp + Vector3(0.72, 0.0, 0.0), Vector3(0.06, 2.0, 1.0), lm, false)
	var zeng = L * 0.12
	var fw = minf(B * 0.5, 7.0)
	var fl = L * 0.34
	box(cx, Vector3(0, ye - 0.1, zeng), Vector3(fw, 0.2, fl), mat(Color("4d5257"), 0.8, 0.4), true)
	var em = mat(Color("2d6a4f"), 0.5, 0.5)
	var gm = mat(Color("8d99ae"), 0.4, 0.7)
	for s in [-1.0, 1.0]:
		box(cx, Vector3(s * fw * 0.28, ye + 1.1, zeng - fl * 0.12), Vector3(1.8, 2.2, fl * 0.38), em, true)
		cyl(cx, Vector3(s * fw * 0.28, ye + 2.4, zeng - fl * 0.12), 0.25, fl * 0.38, gm, false, 0.0, -1.0, Vector3(PI * 0.5, 0, 0))
		cyl(cx, Vector3(s * fw * 0.3, ye + 0.9, zeng + fl * 0.3), 0.6, 1.8, gm, true)
	box(cx, Vector3(0, ye + 1.0, zeng + fl * 0.46), Vector3(2.0, 1.4, 0.5), mat(Color("1d2125"), 0.6), true)
	box(cx, Vector3(0, ye + 1.5, zeng + fl * 0.46 - 0.27), Vector3(1.6, 0.5, 0.04), mat(Color("42d392"), 0.3, 0.0, 1.5), false)
	omni(cx, Vector3(0, ye + 2.4, zeng - 3.0), 12.0, 1.0, Color(1.0, 0.85, 0.6))
	omni(cx, Vector3(0, ye + 2.4, zeng + 4.0), 12.0, 1.0, Color(1.0, 0.85, 0.6))
	var down = Vector3(0, ye + 0.15, zeng + fl * 0.3)
	var up = Vector3(-(half - 0.9) + 1.2, y0 + 0.15, zf + 1.4)
	GameData.make_interact(ship, lp + Vector3(0.9, 0, 0), "Crew lift: engine room", Callable(GameData.main, "teleport_on_ship").bind(ship, down))
	GameData.make_interact(ship, Vector3(0, ye + 1.0, zeng + fl * 0.3 - 1.8), "Crew lift: main deck", Callable(GameData.main, "teleport_on_ship").bind(ship, up))


static func containers(cx, spec, z0, z1, tiers):
	var cl = 12.2
	var cw = 2.44
	var chh = 2.6
	var cols = int((spec.B - 3.6) / (cw + 0.15))
	var rows = int((z1 - z0) / (cl + 0.3))
	if cols < 1 or rows < 1:
		return
	var mm = MultiMesh.new()
	mm.transform_format = MultiMesh.TRANSFORM_3D
	mm.use_colors = true
	var bm = BoxMesh.new()
	bm.size = Vector3(cw, chh, cl)
	mm.mesh = bm
	mm.instance_count = cols * rows * tiers
	var pal = [Color("c0392b"), Color("2e6da4"), Color("e0a526"), Color("2f8f5b"), Color("8e5a3c"), Color("d9d9d9"), Color("1f2a44")]
	var rng = RandomNumberGenerator.new()
	rng.seed = 7
	var idx = 0
	for t in range(tiers):
		for r in range(rows):
			for c in range(cols):
				mm.set_instance_transform(idx, Transform3D(Basis(), Vector3((c - (cols - 1) * 0.5) * (cw + 0.15), spec.free + chh * 0.5 + t * chh, z0 + (r + 0.5) * (cl + 0.3))))
				mm.set_instance_color(idx, pal[rng.randi() % pal.size()])
				idx += 1
	var m = StandardMaterial3D.new()
	m.vertex_color_use_as_albedo = true
	m.roughness = 0.7
	var mi = MultiMeshInstance3D.new()
	mi.multimesh = mm
	mi.material_override = m
	cx.ship.add_child(mi)
	cx.ship.cargo_mm = mi
	cx.ship.cargo_total = idx
	var cs = CollisionShape3D.new()
	var sh = BoxShape3D.new()
	sh.size = Vector3(cols * (cw + 0.15), chh * tiers, rows * (cl + 0.3))
	cs.shape = sh
	cs.position = Vector3(0, spec.free + chh * tiers * 0.5, z0 + rows * (cl + 0.3) * 0.5)
	cx.body.add_child(cs)


static func navlight(cx, pos, col):
	var n = Node3D.new()
	n.position = pos
	var mi = MeshInstance3D.new()
	var sp = SphereMesh.new()
	sp.radius = 0.12
	sp.height = 0.24
	mi.mesh = sp
	mi.material_override = mat(col, 0.3, 0.0, 3.0)
	n.add_child(mi)
	var l = OmniLight3D.new()
	l.light_color = col
	l.omni_range = 14.0
	l.light_energy = 0.7
	n.add_child(l)
	n.visible = false
	cx.ship.add_child(n)
	cx.ship.nav_nodes.append(n)


static func wake(L, B):
	var st = SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)
	var c0 = Color(1, 1, 1, 0.55)
	var c1 = Color(1, 1, 1, 0.0)
	var ap = Vector3(0, 0.05, L * 0.3)
	var lf = Vector3(-B * 1.7, 0.05, L * 0.3 + L * 1.1)
	var rt = Vector3(B * 1.7, 0.05, L * 0.3 + L * 1.1)
	var mid = Vector3(0, 0.05, L * 0.3 + L * 1.1)
	for t in [[ap, lf, mid], [ap, mid, rt]]:
		st.set_color(c0)
		st.add_vertex(t[0])
		st.set_color(c1)
		st.add_vertex(t[1])
		st.set_color(c1 if false else Color(1, 1, 1, 0.0))
		st.add_vertex(t[2])
	for s in [-1.0, 1.0]:
		var a = Vector3(s * B * 0.5, 0.06, -L * 0.45)
		var b = Vector3(s * B * 0.5, 0.06, L * 0.3)
		var b2 = Vector3(s * (B * 0.5 + 1.2), 0.06, L * 0.3)
		var a2 = Vector3(s * (B * 0.5 + 0.5), 0.06, -L * 0.45)
		for v in [[a, c0], [b, c0], [b2, c1], [a, c0], [b2, c1], [a2, c1]]:
			st.set_color(v[1])
			st.add_vertex(v[0])
	var mi = MeshInstance3D.new()
	mi.mesh = st.commit()
	var m = StandardMaterial3D.new()
	m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	m.vertex_color_use_as_albedo = true
	m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	m.cull_mode = BaseMaterial3D.CULL_DISABLED
	mi.material_override = m
	mi.top_level = true
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	return mi


static func sail_tri(h, ln, col):
	var st = SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)
	for v in [Vector3(0, 0.15, 0.1), Vector3(0, h, 0.05), Vector3(0, 0.15, ln)]:
		st.add_vertex(v)
	st.generate_normals()
	var mi = MeshInstance3D.new()
	mi.mesh = st.commit()
	mi.material_override = mat(col, 0.9, 0.0, 0.0, 1.0, true)
	return mi


static func build_sail(cx, spec, ip):
	var ship = cx.ship
	var L = spec.L
	var B = spec.B
	var free = spec.free
	var wm = mat(Color("ece8df"), 0.7)
	var gm = mat(Color(0.25, 0.4, 0.5), 0.1, 0.3, 0.0, 0.35)
	var wood = mat(Color("8b6b43"), 0.7)
	# keel
	box(cx, Vector3(0, -spec.draft * 0.5 + free * 0.2, 0), Vector3(0.25, spec.draft * 0.8, L * 0.16), mat(Color("303438"), 0.5, 0.4), false)
	# doghouse cabin
	var cz = -L * 0.02
	var cl = L * 0.3
	var cw = B * 0.6
	var ch = 2.3
	_wbox(cx, "x", cw * 0.5, cz - cl * 0.5, cz + cl * 0.5, free, ch, 0.12, wm, 300.0)
	_wbox(cx, "x", -cw * 0.5, cz - cl * 0.5, cz + cl * 0.5, free, ch, 0.12, wm, 300.0)
	_wbox(cx, "z", cz - cl * 0.5, 0.0, cw, free, ch, 0.12, wm, 300.0)
	_wbox(cx, "z", cz - cl * 0.5, 0.0, cw, free, ch, 0.12, wm, 300.0)
	wall_run(cx, "z", cz + cl * 0.5, -cw * 0.5, cw * 0.5, free, ch, [[0.0, 0.9]], false, wm, gm)
	box(cx, Vector3(0, free + ch + 0.06, cz), Vector3(cw + 0.2, 0.12, cl + 0.2), wm, true)
	make_door(cx, Vector3(-0.45, free, cz + cl * 0.5), 0.9, 2.0, Vector3(1, 0, 0), wood, 1.0)
	box(cx, Vector3(-cw * 0.5 + 0.5, free + 0.35, cz), Vector3(0.8, 0.5, cl - 0.6), wood, true)
	box(cx, Vector3(cw * 0.5 - 0.5, free + 0.35, cz), Vector3(0.8, 0.5, cl - 0.6), wood, true)
	box(cx, Vector3(0, free + 0.5, cz), Vector3(0.6, 0.06, 0.8), wood, false)
	omni(cx, Vector3(0, free + 1.9, cz), 5.0, 0.8)
	# masts
	var masts = [[-L * 0.22, L * 1.3, L * 0.36]]
	if spec.id == "schooner":
		masts = [[-L * 0.25, L * 0.95, L * 0.28], [L * 0.1, L * 1.1, L * 0.34]]
	var sm = mat(Color("b5b8bd"), 0.4, 0.6)
	for ms in masts:
		cyl(cx, Vector3(0, free + ms[1] * 0.5, ms[0]), 0.08, ms[1], sm, false, 400.0)
		var piv = Node3D.new()
		piv.position = Vector3(0, free + 1.4, ms[0])
		ship.add_child(piv)
		piv.add_child(sail_tri(ms[1] - 1.6, ms[2], Color("f5f1e6")))
		var bm = box(cx, Vector3(0, 0.15, ms[2] * 0.5), Vector3(0.07, 0.07, ms[2]), sm, false)
		ship.remove_child(bm)
		piv.add_child(bm)
		ship.sail_pivots.append({"node": piv, "type": "main"})
	# jib on forestay
	var fm = masts[0]
	var jp = Node3D.new()
	jp.position = Vector3(0, free + 0.4, -L * 0.46)
	ship.add_child(jp)
	var jl = fm[0] + L * 0.46
	jp.add_child(sail_tri(fm[1] * 0.85, jl * 0.9, Color("fbf7ee")))
	ship.sail_pivots.append({"node": jp, "type": "jib"})
	# helm
	var hz = L * 0.38
	cyl(cx, Vector3(0, free + 0.5, hz), 0.12, 1.0, sm, true)
	var wp = Node3D.new()
	wp.position = Vector3(0, free + 1.1, hz - 0.05)
	wp.rotation.x = deg_to_rad(70.0)
	ship.add_child(wp)
	var wr = Node3D.new()
	wp.add_child(wr)
	var tm = MeshInstance3D.new()
	var tor = TorusMesh.new()
	tor.inner_radius = 0.22
	tor.outer_radius = 0.28
	tm.mesh = tor
	tm.material_override = wood
	wr.add_child(tm)
	for a in range(3):
		var sp = box(cx, Vector3.ZERO, Vector3(0.52, 0.03, 0.03), wood, false)
		ship.remove_child(sp)
		sp.rotation.y = a * PI / 3.0
		wr.add_child(sp)
	ship.wheel_rot = wr
	ship.helm_local = Vector3(0, free + 0.05, hz + 0.8)
	ship.eye_local = Vector3(0, free + 1.65, hz + 0.8)
	ship.deck_spawn = Vector3(0, free + 0.3, L * 0.3)
	ship.gang = [Vector3(-(B * 0.5 - 0.7), free + 0.3, L * 0.15), Vector3(B * 0.5 - 0.7, free + 0.3, L * 0.15)]
	ship.pax_zone = Rect2(-B * 0.3, L * 0.18, B * 0.6, L * 0.14)
	ship.pax_y = free
	navlight(cx, Vector3(0, free + masts[0][1] + 0.2, masts[0][0]), Color(1, 1, 1))
	navlight(cx, Vector3(-B * 0.5 + 0.1, free + 0.5, -L * 0.3), Color(1, 0.1, 0.1))
	navlight(cx, Vector3(B * 0.5 - 0.1, free + 0.5, -L * 0.3), Color(0.1, 1, 0.2))
	navlight(cx, Vector3(0, free + 0.8, L * 0.5 - 0.3), Color(1, 1, 1))
	if cx.detail:
		GameData.make_interact(ship, ship.helm_local + Vector3(0, 1.0, -0.8), "Take the helm", Callable(GameData.main, "enter_helm").bind(ship))


static func build_power(cx, spec, ip):
	var ship = cx.ship
	var L = spec.L
	var B = spec.B
	var free = spec.free
	var kind = spec.kind
	var det = cx.detail
	var wm = mat(Color("e8e6e1"), 0.7)
	var gm = mat(Color(0.25, 0.4, 0.5), 0.1, 0.3, 0.0, 0.35)
	var dm = mat(Color("5c6166"), 0.9)
	var doorm = mat(Color("7a5c3c"), 0.7)
	var nlv = {"ferry": 2, "cruise": 5, "general": 3, "bulk": 3, "container": 4, "fishing": 1}
	var ldh = {"ferry": 0.5, "cruise": 0.52, "general": 0.17, "bulk": 0.11, "container": 0.12, "fishing": 0.3}
	var nl = nlv[kind]
	var z_aft = L * 0.32 - 1.0
	var Ldh = maxf(ldh[kind] * L, 5.5 * (nl - 1) + 9.0 if nl > 1 else 4.0)
	Ldh = minf(Ldh, z_aft + L * 0.22 - 3.0)
	var z_front = z_aft - Ldh
	var W = maxf(B - 3.6, 3.0)
	var H = 3.0
	var hw = W * 0.5
	var lodv = 400.0
	for k in range(1, nl):
		var y0 = free + (k - 1) * H
		var zf = z_front + (k - 1) * 5.5
		wall_run(cx, "x", hw, zf, z_aft, y0, 2.9, [], true, wm, gm, lodv)
		wall_run(cx, "x", -hw, zf, z_aft, y0, 2.9, [], true, wm, gm, lodv)
		wall_run(cx, "z", zf, -hw, hw, y0, 2.9, [[0.0, 1.2]], true, wm, gm, lodv)
		wall_run(cx, "z", z_aft, -hw, hw, y0, 2.9, [], false, wm, gm, lodv)
		if det:
			make_door(cx, Vector3(-0.6, y0, zf), 1.2, 2.1, Vector3(1, 0, 0), doorm, 1.0)
			if kind == "ferry" and k == 1:
				saloon(cx, zf, z_aft - 0.3, W, y0, ip)
			else:
				interior(cx, zf, z_aft - 0.3, W, y0, k, ip, 6.0 if kind == "cruise" else 8.0, 6.0 if k == 1 else 0.0)
			if k == 1:
				lift_and_engine(cx, ship, spec, zf, W, y0)
		# roof slab = floor of next level
		box(cx, Vector3(0, y0 + H - 0.1, (zf + z_aft) * 0.5), Vector3(W, 0.2, z_aft - zf), dm, true)
		# stairs up (external ramp on alternating sides)
		var side = 1.0 if k % 2 == 1 else -1.0
		var rx = side * (hw + 0.9)
		ramp(cx, Vector3(rx, y0, zf + 4.8), Vector3(rx, y0 + H, zf + 0.3), 1.5, dm)
		if k >= 2:
			box(cx, Vector3(rx, y0 * 0.5 + 0.0, zf + 2.5), Vector3(0.15, maxf(y0, 0.2), 0.15), mat(Color("9aa1a6")), false, Vector3.ZERO, 200.0)
		# terrace rails on the new slab
		var ys = y0 + H
		rail(cx, Vector3(-hw, ys, zf), Vector3(hw, ys, zf), 1.0)
		rail(cx, Vector3(-side * hw, ys, zf), Vector3(-side * hw, ys, zf + 5.5), 1.0)
	# bridge level
	var yb = free + (nl - 1) * H
	var zb = z_front + (nl - 1) * 5.5
	var Wb = W if nl == 1 else W - 3.0
	var Lb = Ldh if nl == 1 else minf(7.0, z_aft - 3.0 - zb)
	var z1 = zb + Lb
	var bh = Wb * 0.5
	wall_run(cx, "x", bh, zb, z1, yb, 2.9, [[zb + 3.0, 1.0]], true, wm, gm, lodv)
	wall_run(cx, "x", -bh, zb, z1, yb, 2.9, [[zb + 3.0, 1.0]], true, wm, gm, lodv)
	wall_run(cx, "z", zb, -bh, bh, yb, 2.9, [], true, wm, gm, lodv)
	wall_run(cx, "z", z1, -bh, bh, yb, 2.9, [], false, wm, gm, lodv)
	box(cx, Vector3(0, yb + 3.0, (zb + z1) * 0.5), Vector3(Wb + 0.4, 0.2, Lb + 0.4), wm, true)
	if det:
		make_door(cx, Vector3(bh, yb, zb + 2.5), 1.0, 2.1, Vector3(0, 0, 1), doorm, 1.0)
		make_door(cx, Vector3(-bh, yb, zb + 2.5), 1.0, 2.1, Vector3(0, 0, 1), doorm, -1.0)
	var cons = mat(Color("2b2f33"), 0.6)
	box(cx, Vector3(0, yb + 0.475, zb + 0.8), Vector3(maxf(Wb - 0.6, 1.5), 0.95, 0.9), cons, true)
	ship.helm_local = Vector3(0, yb + 0.05, zb + 2.3)
	ship.eye_local = Vector3(0, yb + 1.65, zb + 2.3)
	var wp = Node3D.new()
	wp.position = Vector3(0, yb + 1.25, zb + 1.35)
	wp.rotation.x = deg_to_rad(70.0)
	ship.add_child(wp)
	var wr = Node3D.new()
	wp.add_child(wr)
	var tm = MeshInstance3D.new()
	var tor = TorusMesh.new()
	tor.inner_radius = 0.2
	tor.outer_radius = 0.26
	tm.mesh = tor
	tm.material_override = mat(Color("7a5c3c"), 0.6)
	wr.add_child(tm)
	for a in range(3):
		var sp = box(cx, Vector3.ZERO, Vector3(0.48, 0.03, 0.03), mat(Color("7a5c3c")), false)
		ship.remove_child(sp)
		sp.rotation.y = a * PI / 3.0
		wr.add_child(sp)
	ship.wheel_rot = wr
	var tp = Node3D.new()
	tp.position = Vector3(1.0 if Wb > 3.0 else 0.6, yb + 0.95, zb + 0.9)
	ship.add_child(tp)
	var lev = box(cx, Vector3(0, 0.2, 0), Vector3(0.06, 0.4, 0.06), mat(Color("c0392b")), false)
	ship.remove_child(lev)
	tp.add_child(lev)
	ship.telegraph = tp
	if det:
		var sx = -bh + 0.9
		for scr in [[sx, "radar"], [sx + 1.2, "chart"]]:
			var vp = SubViewport.new()
			vp.size = Vector2i(384, 384)
			vp.render_target_update_mode = SubViewport.UPDATE_DISABLED
			var d = load("res://scripts/display.gd").new()
			d.mode = scr[1]
			d.ship = ship
			d.size = Vector2(384, 384)
			vp.add_child(d)
			ship.add_child(vp)
			ship.screen_vps.append(vp)
			var q = MeshInstance3D.new()
			var qm = QuadMesh.new()
			qm.size = Vector2(0.9, 0.9)
			q.mesh = qm
			var m = StandardMaterial3D.new()
			m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
			m.albedo_texture = vp.get_texture()
			q.material_override = m
			q.position = Vector3(scr[0] if Wb > 4.0 else (0.0 if scr[1] == "radar" else 5.0), yb + 1.3, zb + 0.5)
			q.rotation.x = deg_to_rad(-20.0)
			ship.add_child(q)
		omni(cx, Vector3(0, yb + 2.6, zb + 2.0), 7.0, 0.8, Color(0.8, 0.9, 1.0))
		box(cx, Vector3(0, yb + 0.5, z1 - 0.6), Vector3(Wb - 1.0, 0.9, 0.7), mat(Color("c8b99a"), 0.8), true)
		GameData.make_interact(ship, ship.helm_local + Vector3(0, 1.0, -0.6), "Take the helm", Callable(GameData.main, "enter_helm").bind(ship))
	# rails on the bridge-level slab
	if nl > 1:
		var side = 1.0 if (nl - 1) % 2 == 1 else -1.0
		var zs = z_front + (nl - 2) * 5.5
		var ys = yb
		rail(cx, Vector3(-hw, ys, zs), Vector3(hw, ys, zs), 1.0)
		rail(cx, Vector3(-side * hw, ys, zs), Vector3(-side * hw, ys, z_aft), 1.0)
		rail(cx, Vector3(side * hw, ys, zs + 5.2), Vector3(side * hw, ys, z_aft), 1.0)
		rail(cx, Vector3(-hw, ys, z_aft), Vector3(hw, ys, z_aft), 1.0)
	# roof gear
	var yr = yb + 3.1
	cyl(cx, Vector3(0, yr + 1.6, (zb + z1) * 0.5), 0.07, 3.2, mat(Color("b5b8bd"), 0.4, 0.6), false, 500.0)
	navlight(cx, Vector3(0, yr + 3.3, (zb + z1) * 0.5), Color(1, 1, 1))
	var sc = Node3D.new()
	sc.position = Vector3(0, yr + 0.9, zb + 1.0)
	ship.add_child(sc)
	cyl(cx, Vector3(0, yr + 0.45, zb + 1.0), 0.1, 0.9, mat(Color("9aa1a6")), false, 500.0)
	var bar = box(cx, Vector3(0, 0, 0), Vector3(0.1, 0.06, clampf(L * 0.03, 0.8, 3.0)), mat(Color("303438")), false)
	ship.remove_child(bar)
	sc.add_child(bar)
	ship.scanner = sc
	var fr = clampf(L * 0.02, 0.8, 2.6)
	cyl(cx, Vector3(0, yr + fr * 2.0, z1 - 1.3 if kind != "fishing" else zb + 2.0), fr, fr * 4.0, mat(Color("c0392b") if kind != "cruise" else Color("1d3557"), 0.6), false, 600.0, fr * 0.8)
	navlight(cx, Vector3(-bh - 0.6, yb + 1.8, zb + 2.5), Color(1, 0.1, 0.1))
	navlight(cx, Vector3(bh + 0.6, yb + 1.8, zb + 2.5), Color(0.1, 1, 0.2))
	navlight(cx, Vector3(0, free + 1.5, L * 0.5 - 0.5), Color(1, 1, 1))
	# deck equipment by kind
	box(cx, Vector3(0, free + 0.4, -L * 0.4), Vector3(1.6, 0.8, 1.4), mat(Color("c0392b"), 0.6), true, Vector3.ZERO, 300.0)
	var av = cyl(cx, Vector3(B * 0.35, free - 2.0, -L * 0.46), 0.08, 4.0, mat(Color("222629")))
	av.visible = false
	ship.anchor_vis = av
	var zs0 = -L * 0.22 + 4.0
	var zs1 = z_front - 8.0
	if kind == "container":
		containers(cx, spec, zs0, zs1, 5)
	elif kind == "general":
		containers(cx, spec, zs0 + 20.0, zs1, 2)
		for s in [-1.0, 1.0]:
			cyl(cx, Vector3(s * (B * 0.5 - 1.2), free + 4.0, zs0 + 8.0), 0.5, 8.0, mat(Color("e0a526")), false, 400.0)
			box(cx, Vector3(s * (B * 0.5 - 1.2), free + 8.0, zs0 + 14.0), Vector3(0.4, 0.4, 14.0), mat(Color("e0a526")), false, Vector3(0.35, 0, 0), 400.0)
	elif kind == "bulk":
		var z = zs0 + 6.0
		while z < zs1 - 8.0:
			box(cx, Vector3(0, free + 0.4, z), Vector3(B - 8.0, 0.8, 14.0), mat(Color("6b7075"), 0.8), true, Vector3.ZERO, 500.0)
			z += 20.0
		for s in [-1.0, 1.0]:
			cyl(cx, Vector3(s * (B * 0.5 - 1.5), free + 5.0, z_front - 14.0), 0.7, 10.0, mat(Color("e0a526")), false, 500.0)
			box(cx, Vector3(s * (B * 0.5 - 1.5), free + 10.0, z_front - 24.0), Vector3(0.5, 0.5, 22.0), mat(Color("e0a526")), false, Vector3(0.3, 0, 0), 500.0)
	elif kind == "cruise":
		for s in [-1.0, 1.0]:
			for i in range(6):
				box(cx, Vector3(s * (hw + 0.7), free + 2.2 * 1.0 + H, z_front + 14.0 + i * 12.0), Vector3(1.2, 1.1, 6.5), mat(Color("e67e22"), 0.6), false, Vector3.ZERO, 350.0)
		box(cx, Vector3(0, free + 0.1, -L * 0.12), Vector3(B * 0.4, 0.2, 16.0), mat(Color("1b8fb5"), 0.1, 0.0, 0.5), false, Vector3.ZERO, 400.0)
	ship.gang = [Vector3(-(B * 0.5 - 0.9), free + 0.3, zs1 + 3.0), Vector3(B * 0.5 - 0.9, free + 0.3, zs1 + 3.0)]
	ship.deck_spawn = Vector3(0, free + 0.3, z_front - 4.0)
	ship.pax_zone = Rect2(-W * 0.4, -L * 0.2, W * 0.8, maxf(z_front - 6.0 + L * 0.2, 6.0))
	ship.pax_y = free


static func build(ship, spec, detail, paint, ip):
	var body = StaticBody3D.new()
	ship.add_child(body)
	ship.body = body
	var cx = {"ship": ship, "body": body, "posts": [], "detail": detail}
	var L = spec.L
	var B = spec.B
	var draft = spec.draft * (0.5 if spec.kind == "sail" else 1.0)
	hull(cx, L, B, draft, spec.free, paint)
	var dm = mat(Color("8b6b43") if spec.kind == "sail" else Color("5c6166"), 0.85, 0.0, 0.0, 1.0, true)
	deck_part(cx, L, B, spec.free, 0.0, 0.28, dm)
	deck_part(cx, L, B, spec.free, 0.82, 1.0, dm)
	box(cx, Vector3(0, spec.free - 0.15, -L * 0.5 + L * 0.55), Vector3(B, 0.3, L * 0.54), dm, true)
	hull_rails(cx, L, B, spec.free, 0.6 if spec.kind == "sail" else 1.0)
	if spec.kind == "sail":
		build_sail(cx, spec, ip)
	else:
		build_power(cx, spec, ip)
	finish_posts(cx)
	ship.wake_node = wake(L, B)
	ship.add_child(ship.wake_node)
	# passenger figures (shown according to the load)
	var pr = Node3D.new()
	ship.add_child(pr)
	ship.pax_root = pr
	if detail and spec.pax > 0:
		var rng = RandomNumberGenerator.new()
		rng.seed = 5
		for i in range(24):
			var f = MeshInstance3D.new()
			var cm = CapsuleMesh.new()
			cm.radius = 0.22
			cm.height = 1.5
			f.mesh = cm
			f.material_override = mat(Color.from_hsv(rng.randf(), 0.5, 0.8), 0.9)
			f.position = Vector3(ship.pax_zone.position.x + rng.randf() * ship.pax_zone.size.x, ship.pax_y + 0.75, ship.pax_zone.position.y + rng.randf() * ship.pax_zone.size.y)
			f.visible = false
			f.visibility_range_end = 120.0
			pr.add_child(f)
