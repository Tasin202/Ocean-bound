extends CharacterBody3D
# Walking character (works while parented to a moving ship).

var move_vec = Vector2.ZERO
var yaw = 0.0
var frozen = false
var body_mesh = null


func _ready():
	var cs = CollisionShape3D.new()
	var cap = CapsuleShape3D.new()
	cap.radius = 0.3
	cap.height = 1.8
	cs.shape = cap
	cs.position = Vector3(0, 0.9, 0)
	add_child(cs)
	body_mesh = Node3D.new()
	add_child(body_mesh)
	var m = MeshInstance3D.new()
	var cm = CapsuleMesh.new()
	cm.radius = 0.28
	cm.height = 1.5
	m.mesh = cm
	m.position.y = 0.75
	var mt = StandardMaterial3D.new()
	mt.albedo_color = Color("2b5c8a")
	m.material_override = mt
	body_mesh.add_child(m)
	var h = MeshInstance3D.new()
	var sp = SphereMesh.new()
	sp.radius = 0.16
	sp.height = 0.32
	h.mesh = sp
	h.position.y = 1.62
	var ht = StandardMaterial3D.new()
	ht.albedo_color = Color("e0b48f")
	h.material_override = ht
	body_mesh.add_child(h)
	floor_max_angle = deg_to_rad(50.0)
	floor_snap_length = 0.4


func _physics_process(dt):
	if frozen:
		velocity = Vector3.ZERO
		return
	var dir = Basis(Vector3.UP, yaw) * Vector3(move_vec.x, 0, move_vec.y) * 3.2
	velocity.x = dir.x
	velocity.z = dir.z
	if is_on_floor():
		velocity.y = -1.0
	else:
		velocity.y -= 14.0 * dt
	move_and_slide()
	if dir.length() > 0.1:
		body_mesh.rotation.y = lerp_angle(body_mesh.rotation.y, atan2(-dir.x, -dir.z) - get_parent_rot(), 0.2)


func get_parent_rot():
	var p = get_parent()
	return p.global_rotation.y if p is Node3D else 0.0
