extends Control
# Radar / chart / instrument display. Used in the HUD and on the 3D bridge screens.

var mode = "radar"
var ship = null
var sweep = 0.0
var selected_port = -1
var zoom = 3000.0
var pan = Vector2.ZERO
var follow = true
var route_preview = []
var interactive = false
var font = null


func _ready():
	font = ThemeDB.fallback_font
	mouse_filter = Control.MOUSE_FILTER_STOP if interactive else Control.MOUSE_FILTER_IGNORE


func _process(dt):
	sweep = fmod(sweep + dt * TAU / 2.5, TAU)
	if visible:
		queue_redraw()


func _s(t, p, sz, col):
	draw_string(font, p, t, HORIZONTAL_ALIGNMENT_LEFT, -1, sz, col)


func _draw():
	if ship == null or not is_instance_valid(ship):
		return
	if mode == "radar":
		_radar()
	elif mode == "chart":
		_chart()
	else:
		_instr()


func _rel_to_screen(rel, c, scale):
	if ship.radar_north:
		return c + rel * scale
	var f = ship.fwd()
	return c + Vector2(rel.dot(Vector2(cos(ship.heading), sin(ship.heading))), -rel.dot(f)) * scale


func cpa_of(v):
	var p = v.pos2 - ship.pos2
	var vr = v.vel2 - ship.vel2
	var vv = vr.length_squared()
	if vv < 0.01:
		return [p.length(), 9999.0]
	var t = -p.dot(vr) / vv
	if t < 0.0:
		return [p.length(), -1.0]
	return [(p + vr * t).length(), t]


func detectable(v):
	var rng = ship.radar_range()
	var d = v.pos2.distance_to(ship.pos2)
	var eff = ship.radar_max() * clampf(0.35 + v.spec.L / 180.0, 0.4, 1.0) * (1.0 - 0.35 * GameData.rain)
	return d < minf(rng, eff)


func _radar():
	var c = size * 0.5
	var R = minf(size.x, size.y) * 0.5 - 6.0
	var rng = ship.radar_range()
	var sc = R / rng
	var b = ship.radar_bright
	draw_circle(c, R, Color(0.0, 0.06, 0.04, 0.97))
	for i in range(1, 5):
		draw_arc(c, R * i / 4.0, 0, TAU, 64, Color(0.1, 0.55, 0.3, 0.45 * b), 1.0)
		_s("%d" % int(rng * i / 4.0), c + Vector2(4, -R * i / 4.0 + 12), 12, Color(0.3, 0.9, 0.5, 0.7 * b))
	for k in range(12):
		var a = k * TAU / 12.0
		draw_line(c + Vector2(sin(a), -cos(a)) * (R - 8), c + Vector2(sin(a), -cos(a)) * R, Color(0.3, 0.9, 0.5, 0.8 * b), 1.5)
	var hd = Vector2(sin(ship.heading), -cos(ship.heading)) if ship.radar_north else Vector2(0, -1)
	draw_line(c, c + hd * R, Color(0.9, 0.9, 0.2, 0.7), 1.5)
	for isl in GameData.ISLANDS:
		var ic = Vector2(isl.x, isl.z)
		var pts = []
		for k in range(73):
			var a = k * TAU / 72.0
			var p = ic + Vector2(cos(a), sin(a)) * isl.r
			if p.distance_to(ship.pos2) < rng:
				pts.append(_rel_to_screen(p - ship.pos2, c, sc))
			elif pts.size() > 1:
				draw_polyline(PackedVector2Array(pts), Color(0.3, 1.0, 0.4, 0.9 * b), 2.5)
				pts = []
			else:
				pts = []
		if pts.size() > 1:
			draw_polyline(PackedVector2Array(pts), Color(0.3, 1.0, 0.4, 0.9 * b), 2.5)
	var warn = false
	for v in get_tree().get_nodes_in_group("vessels"):
		if v == ship or not detectable(v):
			continue
		var sp = _rel_to_screen(v.pos2 - ship.pos2, c, sc)
		var ang = atan2(sp.x - c.x, -(sp.y - c.y))
		var age = fmod(sweep - wrapf(ang, 0.0, TAU) + TAU, TAU) / TAU
		var al = (1.0 - 0.75 * age) * b
		var cp = cpa_of(v)
		var danger = cp[0] < 200.0 + ship.spec.L and cp[1] >= 0.0 and cp[1] < 300.0
		var col = Color(1, 0.2, 0.2, al) if danger else Color(0.4, 1.0, 0.5, al)
		draw_rect(Rect2(sp - Vector2(4, 4), Vector2(8, 8)), col, false, 2.0)
		var vd = v.vel2 * 60.0 * sc
		if not ship.radar_north:
			var f = ship.fwd()
			vd = Vector2(vd.dot(Vector2(cos(ship.heading), sin(ship.heading))), -vd.dot(f))
		draw_line(sp, sp + vd, col, 1.0)
		if danger:
			warn = true
		if ship.radar_target == v:
			draw_arc(sp, 11, 0, TAU, 20, Color(1, 0.9, 0.2), 2.0)
			var rel = v.pos2 - ship.pos2
			_s("RNG %dm BRG %03d" % [rel.length(), int(rad_to_deg(atan2(rel.x, -rel.y)) + 360) % 360], Vector2(8, size.y - 40), 14, Color(1, 0.9, 0.3))
			_s("CPA %dm  TCPA %s" % [cp[0], ("%ds" % cp[1]) if cp[1] >= 0.0 and cp[1] < 9000.0 else "--"], Vector2(8, size.y - 22), 14, Color(1, 0.9, 0.3))
	var rn = GameData.rain
	for k in range(int(rn * 70.0 + GameData.world.sea_amp * 8.0 if GameData.world else 0)):
		var a = randf() * TAU
		var d = randf() * R * (0.5 if rn > 0.1 else 0.18)
		draw_circle(c + Vector2(cos(a), sin(a)) * d, 1.2, Color(0.3, 1.0, 0.5, 0.35 * b))
	for k in range(14):
		var a2 = sweep - k * 0.03
		var dv = Vector2(sin(a2), -cos(a2))
		draw_line(c, c + dv * R, Color(0.2, 1.0, 0.5, (0.35 - k * 0.025) * b), 2.0)
	draw_circle(c, 3.0, Color(1, 1, 0.3))
	_s("N-UP" if ship.radar_north else "H-UP", Vector2(8, 16), 14, Color(0.4, 1, 0.6))
	_s("RNG %d m" % int(rng), Vector2(size.x - 100, 16), 14, Color(0.4, 1, 0.6))
	if warn:
		_s("COLLISION WARNING", Vector2(size.x * 0.5 - 70, 36), 16, Color(1, 0.2, 0.2))
		draw_rect(Rect2(0, 0, size.x, size.y), Color(1, 0, 0, 0.12 + 0.1 * sin(Time.get_ticks_msec() * 0.01)))


func _w2s(p):
	return size * 0.5 + (p - (ship.pos2 if follow else pan)) / zoom * (minf(size.x, size.y) * 0.5)


func _s2w(p):
	return (p - size * 0.5) / (minf(size.x, size.y) * 0.5) * zoom + (ship.pos2 if follow else pan)


func _chart():
	draw_rect(Rect2(Vector2.ZERO, size), Color(0.05, 0.16, 0.26))
	var k = minf(size.x, size.y) * 0.5 / zoom
	for isl in GameData.ISLANDS:
		var c = _w2s(Vector2(isl.x, isl.z))
		draw_circle(c, (isl.r + 400.0) * k, Color(0.07, 0.22, 0.34))
		draw_circle(c, (isl.r + 150.0) * k, Color(0.1, 0.32, 0.45))
		draw_circle(c, isl.r * k, Color(0.82, 0.76, 0.52))
		draw_circle(c, isl.r * 0.7 * k, Color(0.32, 0.5, 0.26))
		if zoom < 5000.0:
			_s(isl.name, c + Vector2(-30, 0), 14, Color(1, 1, 1, 0.8))
	for i in range(GameData.PD.size()):
		var p = _w2s(GameData.PD[i].mid)
		var col = Color(1, 0.8, 0.2) if i != selected_port else Color(0.3, 1, 0.6)
		draw_circle(p, 7.0, col)
		_s(GameData.PORTS[i].name, p + Vector2(10, 4), 15, col)
	var rt = ship.route if ship.autopilot == 2 else route_preview
	if rt.size() > 0:
		var pts = [_w2s(ship.pos2)]
		for w in rt:
			pts.append(_w2s(w))
		draw_polyline(PackedVector2Array(pts), Color(1, 0.2, 0.8), 2.5)
	for v in get_tree().get_nodes_in_group("vessels"):
		if v == ship:
			continue
		draw_circle(_w2s(v.pos2), 3.0, Color(0.7, 0.7, 0.7, 0.8))
	var sp = _w2s(ship.pos2)
	var f = ship.fwd()
	draw_colored_polygon(PackedVector2Array([sp + f * 12.0, sp + f.rotated(2.5) * 9.0, sp + f.rotated(-2.5) * 9.0]), Color(0.3, 1, 0.5))
	_s("%d m/px  N is up" % int(zoom / (minf(size.x, size.y) * 0.5)), Vector2(8, size.y - 8), 13, Color(1, 1, 1, 0.7))


func _instr():
	draw_rect(Rect2(Vector2.ZERO, size), Color(0.02, 0.04, 0.06))
	var y = 24.0
	for line in instrument_lines():
		_s(line, Vector2(10, y), 16, Color(0.5, 1.0, 0.8))
		y += 22.0


func latlon(p):
	var lat = 12.0 - p.y / 111000.0
	var lon = 56.0 + p.x / 108000.0
	return "%d %.2f'%s  %d %.2f'%s" % [int(absf(lat)), (absf(lat) - int(absf(lat))) * 60.0, "N" if lat >= 0 else "S", int(absf(lon)), (absf(lon) - int(absf(lon))) * 60.0, "E" if lon >= 0 else "W"]


func instrument_lines():
	var s = ship
	var hd = int(rad_to_deg(s.heading) + 360.0) % 360
	return [
		"HDG %03d  SPD %.1f kn" % [hd, absf(s.speed) * 1.944],
		"SOG %.1f kn COG %03d" % [absf(s.speed) * 1.944, hd],
		"RUDDER %+d deg  RPM %d%%" % [int(s.rudder * 35.0), int(absf(s.throttle) * 100.0)],
		"DEPTH %d m" % int(GameData.depth_at(s.pos2)),
		"POS " + latlon(s.pos2),
		"FUEL %d%%  DMG %d%%" % [int(100.0 * s.fuel / s.fuel_cap()), int(s.damage)],
		"WIND %d kn from %03d" % [int(GameData.wind_speed * 1.944), int(rad_to_deg(GameData.wind_dir) + 360.0) % 360],
	]


func _gui_input(ev):
	if not interactive:
		return
	if ev is InputEventMouseButton and ev.pressed and ev.button_index == MOUSE_BUTTON_LEFT:
		_tap(ev.position)
	elif ev is InputEventMouseMotion and ev.button_mask & MOUSE_BUTTON_MASK_LEFT and mode == "chart":
		if follow:
			follow = false
			pan = ship.pos2
		pan -= ev.relative / (minf(size.x, size.y) * 0.5) * zoom


func _tap(p):
	if mode == "chart":
		var best = -1
		var bd = 40.0
		for i in range(GameData.PD.size()):
			var d = _w2s(GameData.PD[i].mid).distance_to(p)
			if d < bd:
				bd = d
				best = i
		if best >= 0:
			selected_port = best
			route_preview = GameData.find_path(ship.pos2, GameData.PD[best].approach)
			route_preview.append(GameData.PD[best].mid)
			Sfx.play("click")
	elif mode == "radar":
		var c = size * 0.5
		var sc = (minf(size.x, size.y) * 0.5 - 6.0) / ship.radar_range()
		var best2 = null
		var bd2 = 30.0
		for v in get_tree().get_nodes_in_group("vessels"):
			if v == ship or not detectable(v):
				continue
			var d2 = _rel_to_screen(v.pos2 - ship.pos2, c, sc).distance_to(p)
			if d2 < bd2:
				bd2 = d2
				best2 = v
		ship.radar_target = best2
