extends Node
# Fully procedural sound (no asset files): waves, wind, rain, engine, horn, thunder, radar, UI.

const RATE = 22050
var snd = {}
var loops = {}
var rng = RandomNumberGenerator.new()
var built = false


func _wav(samples, loop):
	var s = AudioStreamWAV.new()
	s.format = AudioStreamWAV.FORMAT_16_BITS
	s.mix_rate = RATE
	s.stereo = false
	var b = PackedByteArray()
	b.resize(samples.size() * 2)
	for i in range(samples.size()):
		b.encode_s16(i * 2, int(clampf(samples[i], -1.0, 1.0) * 32000.0))
	s.data = b
	if loop:
		s.loop_mode = AudioStreamWAV.LOOP_FORWARD
		s.loop_begin = 0
		s.loop_end = samples.size()
	return s


func _gen(secs, fn, loop):
	var n = int(RATE * secs)
	var a = PackedFloat32Array()
	a.resize(n)
	for i in range(n):
		a[i] = fn.call(float(i) / RATE, i)
	return _wav(a, loop)


func _noise():
	return rng.randf() * 2.0 - 1.0


func build_all():
	rng.seed = 11
	var y = [0.0]
	var f_waves = func(t, i):
		y[0] += 0.06 * (_noise() - y[0])
		return y[0] * (0.55 + 0.45 * sin(TAU * t / 5.0)) * 3.0
	snd["waves"] = _gen(5.0, f_waves, true)
	await get_tree().process_frame
	var w = [0.0]
	var f_wind = func(t, i):
		w[0] += 0.012 * (_noise() - w[0])
		return w[0] * (0.7 + 0.3 * sin(TAU * t / 4.0)) * 5.0
	snd["wind"] = _gen(4.0, f_wind, true)
	var r = [0.0]
	var f_rain = func(t, i):
		r[0] += 0.3 * (_noise() - r[0])
		return (_noise() - r[0]) * 0.35
	snd["rain"] = _gen(2.0, f_rain, true)
	await get_tree().process_frame
	var f_eng = func(t, i):
		return 0.45 * sin(TAU * 28.0 * t) + 0.25 * sin(TAU * 56.0 * t + 0.5) + 0.15 * sin(TAU * 84.0 * t) + 0.05 * _noise()
	snd["engine"] = _gen(1.0, f_eng, true)
	var f_horn = func(t, i):
		var e = minf(t / 0.05, 1.0) * clampf((2.2 - t) / 0.3, 0.0, 1.0)
		return e * 0.4 * (sin(TAU * 110.0 * t) + 0.7 * sin(TAU * 164.0 * t) + 0.3 * sin(TAU * 220.0 * t))
	snd["horn"] = _gen(2.2, f_horn, false)
	var th = [0.0]
	var f_thunder = func(t, i):
		th[0] += 0.03 * (_noise() - th[0])
		return th[0] * exp(-t * 0.7) * (1.0 + 0.5 * sin(t * 9.0)) * 4.0
	snd["thunder"] = _gen(5.0, f_thunder, false)
	await get_tree().process_frame
	var f_ping = func(t, i):
		return sin(TAU * 1400.0 * t) * exp(-t * 18.0) * 0.6
	snd["ping"] = _gen(0.15, f_ping, false)
	var f_alarm = func(t, i):
		var fr = 900.0 if int(t / 0.15) % 2 == 0 else 1200.0
		return 0.25 if sin(TAU * fr * t) > 0.0 else -0.25
	snd["alarm"] = _gen(0.6, f_alarm, false)
	var tl = [0.0]
	var f_thud = func(t, i):
		tl[0] += 0.1 * (_noise() - tl[0])
		return (tl[0] * 2.0 + sin(TAU * 60.0 * t)) * exp(-t * 8.0)
	snd["thud"] = _gen(0.5, f_thud, false)
	var f_click = func(t, i):
		return sin(TAU * 900.0 * t) * exp(-t * 60.0) * 0.5
	snd["click"] = _gen(0.05, f_click, false)
	var f_gull = func(t, i):
		return sin(TAU * (2000.0 * t - 1200.0 * t * t)) * sin(PI * t / 0.5) * 0.25
	snd["gull"] = _gen(0.5, f_gull, false)
	var f_bell = func(t, i):
		return (sin(TAU * 660.0 * t) + 0.5 * sin(TAU * 1320.0 * t)) * exp(-t * 3.0) * 0.3
	snd["bell"] = _gen(1.2, f_bell, false)
	for k in ["waves", "wind", "rain", "engine"]:
		var p = AudioStreamPlayer.new()
		p.stream = snd[k]
		p.volume_db = -60.0
		add_child(p)
		p.play()
		loops[k] = p
	built = true


func play(name, vol_db = 0.0, pitch = 1.0):
	if not built or not snd.has(name):
		return
	var p = AudioStreamPlayer.new()
	p.stream = snd[name]
	p.volume_db = vol_db + linear_to_db(GameData.settings.sfx)
	p.pitch_scale = pitch
	add_child(p)
	p.play()
	p.finished.connect(p.queue_free)


func apply_master():
	AudioServer.set_bus_volume_db(0, linear_to_db(maxf(GameData.settings.master, 0.001)))


# ctx: sea (wave amp), wind (m/s), rain 0..1, rpm 0..1, engine_on, inside 0 outside / 1 interior / 2 engine room
func update_mix(ctx):
	if not built:
		return
	var sfx = GameData.settings.sfx
	var ins = [1.0, 0.35, 0.2][ctx.inside]
	_vol("waves", clampf(0.12 + ctx.sea * 0.22, 0.0, 0.9) * sfx * ins)
	_vol("wind", clampf(ctx.wind / 22.0, 0.0, 1.0) * 0.8 * sfx * ins)
	_vol("rain", ctx.rain * 0.6 * sfx * (1.0 if ctx.inside == 0 else 0.5))
	var ev = (0.15 + 0.6 * ctx.rpm) * sfx * (0.7 if ctx.inside == 0 else (1.0 if ctx.inside == 1 else 1.8))
	_vol("engine", ev if ctx.engine_on else 0.0)
	loops["engine"].pitch_scale = 0.6 + ctx.rpm * 0.9


func _vol(k, v):
	loops[k].volume_db = linear_to_db(maxf(v, 0.0001))
