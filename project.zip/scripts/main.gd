extends Node
# Game flow: loading, menu, walking/helm modes, cameras, contracts, ownership, AI, multiplayer ships, saving.

const WorldScript = preload("res://scripts/world.gd")
const ShipScript = preload("res://scripts/ship.gd")
const PlayerScript = preload("res://scripts/player.gd")
const HudScript = preload("res://scripts/hud.gd")
const MenusScript = preload("res://scripts/menus.gd")

var world = null
var cam = null
var player = null
var hud = null
var menus = null
var ships_root = null
var mode = "loading"
var ui_open = false
var cam_mode = 0
var cam_yaw = 0.0
var cam_pitch = -0.15
var collision_alert = false
var owned_nodes = {}
var remote = {}
var last_progress = 0
var menu_t = 0.0
var autosave_t = 0.0
var upkeep_t = 0.0
var alert_t = 0.0
var fps_t = 0.0
var gull_t = 5.0
var res_scale = 1.0
var hud_t = 0.0
var near_prompt = null
var alarm_cd = 0.0
var cine_t = 0.0


func _ready():
	GameData.main = self
	if Net.is_server:
		return
	Sfx.apply_master()
	cam = Camera3D.new()
	cam.far = 14000.0
	cam.fov = 72.0
	add_child(cam)
	cam.current = true
	ships_root = Node3D.new()
	add_child(ships_root)
	world = WorldScript.new()
	add_child(world)
	GameData.world = world
	player = PlayerScript.new()
	player.visible = false
	player.frozen = true
	add_child(player)
	menus = MenusScript.new()
	menus.main = self
	add_child(menus)
	hud = HudScript.new()
	hud.main = self
	add_child(hud)
	Net.chat.connect(func(s, t):
		menus.chat_log.append("%s: %s" % [s, t])
		toast("%s: %s" % [s, t]))
	_boot()


func _boot():
	last_progress = Time.get_ticks_msec()
	menus.loading(0.0, "Starting...")
	await get_tree().process_frame
	var cb = func(f, t):
		last_progress = Time.get_ticks_msec()
		menus.loading(f * 0.85, t)
	await world.build(cb)
	menus.loading(0.88, "Generating audio...")
	await get_tree().process_frame
	await Sfx.build_all()
	last_progress = Time.get_ticks_msec()
	menus.loading(0.95, "Launching maritime traffic...")
	await get_tree().process_frame
	_spawn_ai()
	menus.loading(1.0, "Ready")
	mode = "menu"
	menus.close()
	menus.main_menu()
	check_updates(false)


func _spawn_ai():
	var types = ["ferry", "cruise", "general", "bulk", "container", "trawler", "trawler", "sloop", "schooner", "general"]
	var rng = RandomNumberGenerator.new()
	rng.randomize()
	for t in types:
		var pi = rng.randi() % GameData.PORTS.size()
		var s = make_ship(t, Color.from_hsv(rng.randf(), 0.5, 0.85) if t != "cruise" else Color("f4f4f2"), rng.randi() % 4, false, "ai")
		s.pos2 = GameData.PD[pi].approach + Vector2(rng.randf_range(-300, 300), rng.randf_range(-300, 300))
		if not GameData.seg_clear(s.pos2, s.pos2 + Vector2(1, 1), 50.0):
			s.pos2 = GameData.PD[pi].approach
		s.ai_port = pi
		s.heading = rng.randf() * TAU - PI
		s._ai_next()


func make_ship(type, paint, ip, det, role):
	var s = ShipScript.new()
	s.role = role
	ships_root.add_child(s)
	s.setup(GameData.SHIPS[type], det, paint, ip)
	return s


func ship():
	return GameData.active_ship


func toast(t):
	if hud:
		hud.show_toast(t)


func check_updates(manual):
	var http = HTTPRequest.new()
	http.timeout = 10.0
	add_child(http)
	http.request_completed.connect(func(result, code, headers, body):
		http.queue_free()
		if code != 200:
			if manual:
				menus.update_info = "Update check failed (no connection or no tags yet)"
				menus.update_url = ""
				if mode == "menu":
					menus.main_menu()
			return
		var arr = JSON.parse_string(body.get_string_from_utf8())
		var best = ""
		if typeof(arr) == TYPE_ARRAY:
			for t in arr:
				var n = str(t.get("name", ""))
				if best == "" or _ver_gt(n, best):
					best = n
		if best != "" and _ver_gt(best, GameData.VERSION):
			menus.update_info = "Update available: %s - tap to open" % best
			menus.update_url = "https://github.com/%s/releases/tag/%s" % [GameData.UPDATE_REPO, best]
		elif manual:
			menus.update_info = "You are up to date (v%s)" % GameData.VERSION
			menus.update_url = ""
		if mode == "menu" and menus.update_info != "":
			menus.main_menu())
	http.request("https://api.github.com/repos/%s/tags" % GameData.UPDATE_REPO, ["User-Agent: MaritimeSim", "Accept: application/vnd.github+json"])


func _ver_gt(a, b):
	var pa = a.trim_prefix("v").split(".")
	var pb = b.trim_prefix("v").split(".")
	for i in range(maxi(pa.size(), pb.size())):
		var x = int(pa[i]) if i < pa.size() else 0
		var y = int(pb[i]) if i < pb.size() else 0
		if x != y:
			return x > y
	return false


# ---------------- game start ----------------
func _clear_owned():
	for k in owned_nodes:
		if is_instance_valid(owned_nodes[k]):
			owned_nodes[k].queue_free()
	owned_nodes.clear()
	GameData.active_ship = null


func new_game():
	menus.close()
	_clear_owned()
	GameData.new_game()
	_enter_walk_at_port(1)
	toast("Welcome aboard! Buy your first ship at the yellow dealership kiosk on the quay.")


func continue_game():
	menus.close()
	_clear_owned()
	var ps = GameData.load_game()
	for rec in GameData.owned:
		rec.uid = int(rec.uid)
		_respawn(rec, rec.uid == GameData.active_uid)
	apply_graphics()
	if GameData.active_ship and ps.get("on_ship", false):
		var p = ps.get("p", [0, 3, 0])
		put_player(GameData.active_ship, Vector3(p[0], p[1], p[2]))
		_set_walk()
	else:
		_enter_walk_at_port(GameData.nearest_port(GameData.active_ship.pos2) if GameData.active_ship else 1)


func _enter_walk_at_port(pi):
	var d = GameData.PD[pi]
	put_player(world, Vector3(d.quay.x, 2.7, d.quay.y) - Vector3(d.dir.x, 0, d.dir.y) * 8.0)
	_set_walk()


func _set_walk():
	mode = "walk"
	cam_mode = 0
	player.frozen = false
	player.visible = false
	hud.set_mode("walk")


func put_player(parent, local_pos):
	if player.get_parent():
		player.get_parent().remove_child(player)
	parent.add_child(player)
	player.position = local_pos
	player.velocity = Vector3.ZERO


func player_save():
	if GameData.active_ship and player and player.get_parent() == GameData.active_ship:
		return {"on_ship": true, "p": [player.position.x, player.position.y, player.position.z]}
	return {"on_ship": false}


func to_menu():
	menus.close()
	mode = "menu"
	hud.set_mode("none")
	player.frozen = true
	player.visible = false
	menus.main_menu()


# ---------------- owned ships ----------------
func _respawn(rec, active):
	var uid = int(rec.uid)
	if owned_nodes.has(uid) and is_instance_valid(owned_nodes[uid]):
		owned_nodes[uid].queue_free()
	var s = make_ship(rec.type, Color(rec.paint), int(rec.interior), active, "player" if active else "parked")
	s.uid = uid
	s.pos2 = Vector2(rec.x, rec.z)
	s.heading = rec.h
	s.fuel = rec.fuel
	s.damage = rec.damage
	s.upg = {"engine": int(rec.upg.engine), "hull": int(rec.upg.hull), "radar": int(rec.upg.radar), "fuel": int(rec.upg.fuel)}
	s.anchor = rec.get("anchor", false)
	s.cargo = rec.get("cargo", {})
	s.lights_on = rec.get("lights", false)
	if int(rec.get("port", -1)) >= 0:
		s.moored = true
		s.moor_port = int(rec.port)
		s.moor_pos = Vector2(rec.mx, rec.mz)
		s.moor_head = rec.mh
	s._pose(0.1)
	if not s.cargo.is_empty():
		s.set_load_visuals(float(s.cargo.amount) / float(maxi(1, s.spec.pax if s.spec.pax > 0 else s.spec.cargo)))
	else:
		s.set_load_visuals(0.0)
	owned_nodes[uid] = s
	if active:
		GameData.active_ship = s
		GameData.active_uid = uid
		for i in range(2):
			GameData.make_interact(s, s.gang[i] + Vector3(0, 1.0, 0), "Disembark to pier", Callable(self, "disembark"))
	return s


func _store(rec, s):
	rec.x = s.pos2.x
	rec.z = s.pos2.y
	rec.h = s.heading
	rec.fuel = s.fuel
	rec.damage = s.damage
	rec.upg = s.upg
	rec.anchor = s.anchor
	rec.cargo = s.cargo
	rec.lights = s.lights_on
	rec.port = s.moor_port if s.moored else -1
	rec.mx = s.moor_pos.x
	rec.mz = s.moor_pos.y
	rec.mh = s.moor_head


func sync_records():
	for rec in GameData.owned:
		var n = owned_nodes.get(int(rec.uid))
		if n and is_instance_valid(n):
			_store(rec, n)


func save():
	sync_records()
	GameData.save_game()


func _rec_by_uid(uid):
	for r in GameData.owned:
		if int(r.uid) == uid:
			return r
	return null


func set_active(uid, board):
	sync_records()
	var old = GameData.active_ship
	if player.get_parent() == old and old != null:
		put_player(world, player.global_position)
		if mode == "helm":
			leave_helm()
	if old and is_instance_valid(old):
		var ro = _rec_by_uid(old.uid)
		if ro:
			_respawn(ro, false)
	var rn = _rec_by_uid(uid)
	_respawn(rn, true)
	if board:
		put_player(GameData.active_ship, GameData.active_ship.deck_spawn)
		_set_walk()


func switch_ship(idx):
	if not GameData.spend(250, "Crew transfer"):
		toast("Not enough money")
		return
	set_active(int(GameData.owned[idx].uid), true)


func buy_ship(type, paint_i, int_i, pi):
	var sp = GameData.SHIPS[type]
	if not GameData.spend(sp.price, "Bought " + sp.name):
		toast("Not enough money")
		return false
	var side = 1.0
	for n in owned_nodes.values():
		if is_instance_valid(n) and n.moored and n.moor_port == pi and n.moor_side() == side:
			side = -1.0
	var bp = GameData.berth_pos(pi, sp, side)
	var hd = GameData.berth_heading(pi, 1.0)
	var rec = {"uid": GameData.next_uid, "type": type, "paint": GameData.HULL_COLORS[paint_i].to_html(false), "interior": int_i, "fuel": sp.fuelcap, "damage": 0.0,
		"upg": {"engine": 0, "hull": 0, "radar": 0, "fuel": 0}, "x": bp.x, "z": bp.y, "h": hd, "port": pi, "mx": bp.x, "mz": bp.y, "mh": hd, "anchor": false, "cargo": {}}
	GameData.next_uid += 1
	GameData.owned.append(rec)
	set_active(int(rec.uid), false)
	toast("%s delivered to the berth at %s. Walk down the pier and board!" % [sp.name, GameData.PORTS[pi].name])
	save()
	return true


func upgrade_ship(idx, k):
	var rec = GameData.owned[idx]
	var sp = GameData.SHIPS[rec.type]
	var lvl = int(rec.upg[k])
	if lvl >= 3 or not GameData.spend(GameData.upg_cost(sp, lvl), "Upgrade %s %s" % [sp.name, k]):
		toast("Cannot upgrade")
		return
	rec.upg[k] = lvl + 1
	var n = owned_nodes.get(int(rec.uid))
	if n:
		n.upg[k] = lvl + 1


func repaint_ship(idx, ci):
	var rec = GameData.owned[idx]
	var sp = GameData.SHIPS[rec.type]
	if not GameData.spend(sp.price * 0.01 + 200, "Repaint " + sp.name):
		toast("Not enough money")
		return
	sync_records()
	rec.paint = GameData.HULL_COLORS[ci].to_html(false)
	var on_ship = player.get_parent() == owned_nodes.get(int(rec.uid))
	if on_ship:
		put_player(world, player.global_position + Vector3(0, 2, 0))
	_respawn(rec, int(rec.uid) == GameData.active_uid)
	if on_ship:
		put_player(GameData.active_ship, GameData.active_ship.deck_spawn)


# ---------------- ports & contracts ----------------
func open_port(pi):
	if pi != null and pi >= 0:
		menus.port(pi)


func open_dealer(pi):
	menus.dealer(pi)


func open_map():
	menus.map_screen()


func open_pause():
	menus.pause()


func refuel():
	var s = ship()
	var cost = (s.fuel_cap() - s.fuel) * 1.1
	if GameData.spend(cost, "Fuel"):
		s.fuel = s.fuel_cap()
		toast("Tanks full")
	else:
		toast("Not enough money")


func repair():
	var s = ship()
	var cost = s.damage * s.spec.price * 0.0006
	if GameData.spend(cost, "Repairs"):
		s.damage = 0.0
		toast("Repairs complete")
	else:
		toast("Not enough money")


func accept_contract(c):
	var s = ship()
	if s == null or not s.cargo.is_empty():
		return
	s.cargo = c.duplicate()
	var cap = s.spec.pax if s.spec.pax > 0 else s.spec.cargo
	s.set_load_visuals(float(c.amount) / float(cap))
	toast("Loaded! Sail to %s" % GameData.PORTS[c.to].name)
	Sfx.play("bell")


func complete_contract():
	var s = ship()
	var c = s.cargo
	GameData.add_money(c.reward, "Delivered to " + GameData.PORTS[c.to].name)
	GameData.contracts_done += 1
	s.cargo = {}
	s.set_load_visuals(0.0)
	toast("Contract complete: +$%d" % int(c.reward))
	save()


# ---------------- ship interaction ----------------
func enter_helm(s):
	if s != GameData.active_ship:
		return
	mode = "helm"
	player.frozen = true
	player.visible = false
	put_player(s, s.helm_local)
	cam_mode = 0
	cam_yaw = PI
	cam_pitch = -0.05
	hud.set_mode("helm")


func leave_helm():
	_set_walk()
	cam_mode = 0


func teleport_on_ship(s, local_pos):
	player.position = local_pos
	player.velocity = Vector3.ZERO
	Sfx.play("click")


func disembark():
	var s = ship()
	if s == null or not s.moored:
		toast("Moor alongside a pier first")
		return
	var pi = s.moor_port
	var d = GameData.PD[pi]
	var sd = s.moor_side()
	var wp = d.mid + d.perp * sd * 6.0
	put_player(world, Vector3(wp.x, 2.8, wp.y))
	toast("On the pier")


func board_at_port(pi, side):
	var s = ship()
	if s == null or not s.moored or s.moor_port != pi or s.moor_side() != side:
		toast("Your ship is not moored on this side of the pier")
		return
	var sv = (-GameData.PD[pi].perp * side).dot(Vector2(cos(s.heading), sin(s.heading)))
	put_player(s, s.gang[1 if sv > 0 else 0])
	toast("Welcome aboard")


func toggle_anchor():
	var s = ship()
	if not s.anchor and GameData.depth_at(s.pos2) > 80.0:
		toast("No bottom to anchor in this depth")
		return
	s.anchor = not s.anchor
	toast("Anchor down" if s.anchor else "Anchor raised")
	Sfx.play("thud", -6.0)


func toggle_moor():
	var s = ship()
	if s.moored:
		s.cast_off()
		toast("Cast off")
	elif s.moor():
		GameData.spend(20 + s.spec.L * 3.0, "Docking fee " + GameData.PORTS[s.moor_port].name)
		toast("Moored at %s - open the Port menu" % GameData.PORTS[s.moor_port].name)
		save()
	else:
		toast("Get alongside a pier berth at under 3 knots to moor")


func set_route(pi):
	var s = ship()
	var sd = 1.0
	s.route = GameData.route_to_port(s.pos2, pi, s.spec, sd)
	s.autopilot = 2
	s.route_port = pi
	if s.moored:
		s.cast_off()
	toast("Autopilot following route. Keep watch and manage throttle.")


# ---------------- input from HUD ----------------
func look_delta(dx, dy):
	var k = 0.005 * GameData.settings.sens
	cam_yaw -= dx * k
	cam_pitch = clampf(cam_pitch - dy * k, -1.3, 1.1)


func cycle_cam():
	cam_mode = (cam_mode + 1) % 4
	player.visible = mode == "walk" and cam_mode != 0
	toast(["First person", "Third person", "External free camera", "Cinematic"][cam_mode])


func interact():
	if near_prompt and is_instance_valid(near_prompt):
		near_prompt.get_meta("action").call()


func mp_ready():
	return mode == "walk" or mode == "helm"


func net_correct(p):
	var s = ship()
	if s:
		s.pos2 = p
		s.speed = 0.0
		toast("Server corrected your position")


func apply_graphics():
	res_scale = 1.0
	get_viewport().scaling_3d_scale = 1.0
	world.apply_quality()
	Engine.max_fps = 60


# ---------------- per-frame ----------------
func _process(dt):
	if Net.is_server:
		return
	if mode == "loading":
		if Time.get_ticks_msec() - last_progress > 30000:
			mode = "error"
			menus.loading_error("Loading timed out. Your device may be low on memory. Tap Retry, or lower graphics in Settings.")
		return
	var cpos = cam.global_position
	world.update(dt, cpos)
	_update_cam(dt)
	_scan_interact()
	_traffic_net()
	hud_t += dt
	if hud_t > 0.05:
		hud_t = 0.0
		hud.refresh(ship() if mode == "helm" or mode == "walk" else null)
	fps_t += dt
	if fps_t > 2.0:
		fps_t = 0.0
		var target = [30.0, 45.0, 50.0, 60.0][GameData.settings.gfx]
		var fps = Engine.get_frames_per_second()
		if fps < target * 0.85:
			res_scale = maxf(0.55, res_scale - 0.06)
		elif fps > target * 1.15 and res_scale < 1.0:
			res_scale = minf(1.0, res_scale + 0.03)
		get_viewport().scaling_3d_scale = res_scale
	if mode == "walk" or mode == "helm":
		_gameplay(dt)
	_audio(dt)


func _update_cam(dt):
	var s = ship()
	if mode == "menu" or mode == "error":
		menu_t += dt * 0.05
		var c = Vector3(0, 50, 0)
		cam.global_position = c + Vector3(sin(menu_t) * 900.0, 20, cos(menu_t) * 900.0)
		cam.look_at(c)
		return
	if mode != "walk" and mode != "helm":
		return
	player.yaw = cam_yaw
	player.move_vec = hud.move_vec if mode == "walk" else Vector2.ZERO
	var basis = Basis.from_euler(Vector3(cam_pitch, cam_yaw, 0))
	var target = player.global_position + Vector3(0, 1.5, 0)
	var dist = 4.0
	if s:
		if mode == "helm" or cam_mode >= 2:
			target = s.global_position + Vector3(0, s.spec.free + 2.0, 0)
			dist = s.spec.L * 0.9 + 8.0 if cam_mode <= 1 else s.spec.L * 1.7 + 14.0
	match cam_mode:
		0:
			var ep = (s.to_global(s.eye_local) if mode == "helm" and s else player.global_position + Vector3(0, 1.62, 0))
			cam.global_transform = Transform3D(basis, ep)
		1, 2:
			var pos = target + basis * Vector3(0, 0, dist)
			cam.global_position = cam.global_position.lerp(pos, 1.0 - exp(-dt * 8.0))
			cam.global_transform = Transform3D(basis, cam.global_position)
		3:
			cine_t += dt
			var b2 = Basis.from_euler(Vector3(-0.22 + sin(cine_t * 0.25) * 0.12, cine_t * 0.12, 0))
			cam.global_transform = Transform3D(b2, target + b2 * Vector3(0, 0, (s.spec.L * 1.4 + 14.0) if s else 15.0))
	if cam.global_position.y < 0.6:
		cam.global_position.y = 0.6


func _scan_interact():
	near_prompt = null
	if mode != "walk" or ui_open:
		hud.set_prompt("")
		return
	var best = 2.6
	for n in get_tree().get_nodes_in_group("interact"):
		var d = n.global_position.distance_to(player.global_position + Vector3(0, 1.0, 0))
		if d < best:
			best = d
			near_prompt = n
	hud.set_prompt(near_prompt.get_meta("label") if near_prompt else "")
	if player.global_position.y < -10.0:
		var s = ship()
		if s and player.get_parent() == s:
			player.position = s.deck_spawn
		else:
			_enter_walk_at_port(GameData.nearest_port(Vector2(player.global_position.x, player.global_position.z)))


func _gameplay(dt):
	var s = ship()
	autosave_t += dt
	if autosave_t > 45.0:
		autosave_t = 0.0
		save()
	if s == null:
		return
	upkeep_t += dt
	if upkeep_t > 10.0:
		upkeep_t = 0.0
		if absf(s.speed) > 0.5 and not s.moored:
			GameData.spend(minf(GameData.money, s.spec.upkeep / 6.0), "Operating costs")
	alert_t += dt
	alarm_cd -= dt
	if alert_t > 0.5:
		alert_t = 0.0
		collision_alert = false
		var disp = preload("res://scripts/display.gd").new()
		disp.ship = s
		for v in get_tree().get_nodes_in_group("vessels"):
			if v == s or not disp.detectable(v):
				continue
			var cp = disp.cpa_of(v)
			if cp[0] < 200.0 + s.spec.L and cp[1] >= 0.0 and cp[1] < 300.0 and not s.moored:
				collision_alert = true
		disp.free()
	if collision_alert and alarm_cd <= 0.0:
		alarm_cd = 3.0
		Sfx.play("alarm", -4.0)
	var near = s.screen_vps.size() > 0 and (mode == "helm" or (player.get_parent() == s and (player.position - s.helm_local).length() < 9.0))
	for vp in s.screen_vps:
		vp.render_target_update_mode = SubViewport.UPDATE_ALWAYS if near else SubViewport.UPDATE_DISABLED
	if mode == "helm" and s.fuel <= 0.0 and s.spec.kind != "sail":
		s.throttle = 0.0


func _traffic_net():
	if not Net.online or Net.is_server:
		for k in remote.keys():
			remote[k].queue_free()
		remote.clear()
		return
	for id in Net.players:
		if id == Net.my_id:
			continue
		var p = Net.players[id]
		if not GameData.SHIPS.has(p.ship):
			continue
		if not remote.has(id) or not is_instance_valid(remote[id]) or remote[id].spec.id != p.ship:
			if remote.has(id) and is_instance_valid(remote[id]):
				remote[id].queue_free()
			var s = make_ship(p.ship, Color(p.paint), 0, false, "remote")
			s.pos2 = Vector2(p.x, p.z)
			s.net_name = p.name
			var lab = Label3D.new()
			lab.text = p.name
			lab.billboard = BaseMaterial3D.BILLBOARD_ENABLED
			lab.font_size = 64
			lab.pixel_size = 0.04 * maxf(1.0, s.spec.L / 40.0)
			lab.position = Vector3(0, s.spec.free + 12.0, 0)
			lab.visibility_range_end = 2500.0
			s.add_child(lab)
			remote[id] = s
		remote[id].rtarget = {"x": p.x, "z": p.z, "h": p.h, "v": p.v}
	for id in remote.keys():
		if not Net.players.has(id):
			remote[id].queue_free()
			remote.erase(id)


func _audio(dt):
	var s = ship()
	var inside = 0
	var rpm = 0.0
	var eng = false
	if s and (mode == "walk" or mode == "helm"):
		eng = s.fuel > 0.0 and not s.moored and (s.spec.kind != "sail" or s.throttle > 0.05)
		rpm = clampf(absf(s.throttle), 0.0, 1.0)
		if player.get_parent() == s:
			if player.position.y < s.spec.free - 1.0:
				inside = 2
			elif mode == "helm" and s.spec.kind != "sail":
				inside = 1
	Sfx.update_mix({"sea": world.sea_amp, "wind": GameData.wind_speed, "rain": GameData.rain, "rpm": rpm, "engine_on": eng, "inside": inside})
	gull_t -= dt
	if gull_t <= 0.0:
		gull_t = randf_range(6.0, 16.0)
		var p = Vector2(cam.global_position.x, cam.global_position.z)
		if GameData.PD[GameData.nearest_port(p)].mid.distance_to(p) < 700.0:
			Sfx.play("gull", -8.0, randf_range(0.8, 1.2))


func _notification(what):
	if what == NOTIFICATION_APPLICATION_PAUSED or what == NOTIFICATION_WM_CLOSE_REQUEST:
		if mode == "walk" or mode == "helm":
			save()
