extends Node3D
# A vessel: player ship, parked owned ship, AI traffic or remote multiplayer ship.

const SB = preload("res://scripts/ship_builder.gd")
const RADAR_STEPS = [750.0, 1500.0, 3000.0, 6000.0, 12000.0]

var spec = {}
var role = "ai"        # player | parked | ai | remote
var detail = false
var heading = 0.0
var speed = 0.0
var yawrate = 0.0
var throttle = 0.0
var rudder = 0.0
var sail_trim = 0.5
var fuel = 0.0
var damage = 0.0
var anchor = false
var lights_on = false
var moored = false
var moor_port = -1
var moor_pos = Vector2.ZERO
var moor_head = 0.0
var autopilot = 0
var ap_heading = 0.0
var route = []
var route_port = -1
var pos2 = Vector2.ZERO
var vel2 = Vector2.ZERO
var pitch = 0.0
var roll = 0.0
var cargo = {}
var upg = {"engine": 0, "hull": 0, "radar": 0, "fuel": 0}
var radar_idx = 2
var radar_bright = 0.8
var radar_north = false
var radar_target = null
var ai_wait = 0.0
var ai_port = -1
var grounded = false
var uid = 0
var paint = Color.WHITE
var interior_idx = 0
var net_name = ""
var rtarget = {}
var warn_cd = 0.0
# set by builder
var body = null
var sail_pivots = []
var nav_nodes = []
var scanner = null
var wheel_rot = null
var telegraph = null
var cargo_mm = null
var cargo_total = 0
var pax_root = null
var pax_zone = Rect2()
var pax_y = 0.0
var screen_vps = []
var anchor_vis = null
var wake_node = null
var helm_local = Vector3.ZERO
var eye_local = Vector3(0, 2, 0)
var deck_spawn = Vector3(0, 2, 0)
var gang = [Vector3.ZERO, Vector3.ZERO]


func setup(sp, det, paint_c, ip):
	spec = sp
	detail = det
	paint = paint_c
	interior_idx = ip
	SB.build(self, sp, det, paint_c, ip)
	fuel = fuel_cap()
	if role != "preview":
		add_to_group("vessels")
	radar_idx = 2


func paint_html():
	return paint.to_html(false)


func vmax():
	return spec.vmax * (1.0 + 0.08 * upg.engine) * (1.0 - 0.45 * damage / 100.0)


func fuel_cap():
	return spec.fuelcap * (1.0 + 0.3 * upg.fuel)


func radar_max():
	return spec.radar * (1.0 + 0.25 * upg.radar)


func radar_range():
	return minf(RADAR_STEPS[radar_idx], radar_max())


func fwd():
	return Vector2(sin(heading), -cos(heading))


func sail_speed():
	var a = absf(wrapf(GameData.wind_dir - heading, -PI, PI))
	var eff = pow(sin(minf(a, 2.2)), 0.8) if a < 2.2 else lerpf(0.843, 0.55, (a - 2.2) / (PI - 2.2))
	eff *= smoothstep(0.45, 0.8, a)
	var ideal = clampf((a - 0.6) / (PI - 0.6), 0.0, 1.0)
	var te = 1.0 - minf(1.0, absf(sail_trim - ideal) * 1.6)
	return minf(vmax() * 1.1, vmax() * eff * te * clampf(GameData.wind_speed / 8.0, 0.2, 1.4))


func ideal_trim():
	var a = absf(wrapf(GameData.wind_dir - heading, -PI, PI))
	return clampf((a - 0.6) / (PI - 0.6), 0.0, 1.0)


func hit(impact):
	var d = impact * 1.2 * (1.0 - 0.25 * upg.hull)
	damage = minf(90.0, damage + d)
	if role == "player":
		Sfx.play("thud", 0.0, 0.8)
		if GameData.main:
			GameData.main.toast("Collision! Hull damage %d%%" % int(damage))


func _physics_process(dt):
	if role == "preview":
		return
	if role == "remote":
		_remote(dt)
		return
	if role == "ai":
		_ai(dt)
	if autopilot > 0 and role == "player":
		_autopilot()
	_sim(dt)
	_visuals(dt)


func _sim(dt):
	var vm = vmax()
	var eng = fuel > 0.0 and not moored
	var thr = throttle if eng else 0.0
	var tgt = 0.0
	if spec.kind == "sail":
		tgt = sail_speed() + vm * 0.4 * thr
	else:
		tgt = vm * thr if thr >= 0.0 else vm * 0.35 * thr
	var rate = spec.acc / spec.vmax
	if anchor:
		tgt = 0.0
		rate *= 4.0
	if moored:
		tgt = 0.0
		rate *= 6.0
	speed = lerpf(speed, tgt, 1.0 - exp(-rate * dt))
	if eng and absf(thr) > 0.01 and (spec.kind != "sail" or thr > 0.0):
		fuel = maxf(0.0, fuel - spec.fuelrate * absf(thr) * dt)
	var steer = clampf(absf(speed) / (vm * 0.45 + 0.1), 0.0, 1.0)
	var yt = rudder * deg_to_rad(spec.turn) * steer * signf(speed if absf(speed) > 0.05 else 1.0)
	yawrate = lerpf(yawrate, yt, 1.0 - exp(-dt * 1.2 / (1.0 + spec.L / 60.0)))
	heading = wrapf(heading + yawrate * dt, -PI, PI)
	var old = pos2
	pos2 += fwd() * speed * dt
	if moored:
		pos2 = pos2.lerp(moor_pos, 1.0 - exp(-dt * 0.8))
		heading = lerp_angle(heading, moor_head, 1.0 - exp(-dt * 0.8))
	_collide()
	vel2 = (pos2 - old) / maxf(dt, 0.0001)
	_pose(dt)


func _collide():
	grounded = false
	var g = maxf((spec.draft * 0.8 - 2.0) / 0.1, spec.L * 0.3)
	for isl in GameData.ISLANDS:
		var c = Vector2(isl.x, isl.z)
		var d = pos2.distance_to(c)
		if d < isl.r + g:
			pos2 = c + (pos2 - c).normalized() * (isl.r + g)
			grounded = true
			if absf(speed) > 1.5:
				hit(absf(speed) * 1.5)
			speed *= 0.3
	if not moored:
		for p in GameData.PD:
			var rel = pos2 - p.mid
			var along = rel.dot(p.dir)
			var side = rel.dot(p.perp)
			if absf(along) < 160.0 and absf(side) < 7.0:
				pos2 += p.perp * (7.0 - absf(side)) * signf(side if side != 0.0 else 1.0)
				speed *= 0.5
	for v in get_tree().get_nodes_in_group("vessels"):
		if v == self or v.role == "remote":
			continue
		var rel2 = pos2 - v.pos2
		var lim = (spec.L + v.spec.L) * 0.28
		var dd = rel2.length()
		if dd < lim and dd > 0.01 and not (moored and v.moored):
			pos2 += rel2 / dd * (lim - dd) * 0.5
			if absf(speed - v.speed) > 1.5 and role == "player":
				hit(absf(speed - v.speed))
			speed *= 0.8


func _pose(dt):
	var w = GameData.world
	var h0 = 0.0
	var pt = 0.0
	var rt = 0.0
	if w:
		var f = fwd()
		var r = Vector2(cos(heading), sin(heading))
		var lh = spec.L * 0.35
		var bh = spec.B * 0.5
		var hb = w.wave_h(pos2 + f * lh)
		var hs = w.wave_h(pos2 - f * lh)
		var hr = w.wave_h(pos2 + r * bh)
		var hl = w.wave_h(pos2 - r * bh)
		h0 = (hb + hs + hr + hl) * 0.25
		pt = atan2(hb - hs, lh * 2.0)
		rt = atan2(hr - hl, bh * 2.0)
	var damp = 1.0 / (1.0 + spec.L / 45.0)
	if spec.kind == "sail":
		var a = wrapf(GameData.wind_dir - heading, -PI, PI)
		rt += -signf(a) * clampf(GameData.wind_speed / 25.0, 0.0, 0.5) * sin(absf(a)) * 0.5
	var k = 1.0 - exp(-dt * 2.0)
	pitch = lerpf(pitch, pt * damp * 1.2, k)
	roll = lerpf(roll, rt * damp * 1.2, k)
	position = Vector3(pos2.x, h0 * clampf(1.2 * damp, 0.2, 1.0), pos2.y)
	rotation = Vector3(pitch, -heading, roll)


func _visuals(dt):
	if scanner:
		scanner.rotation.y += dt * TAU / 2.5
	if wheel_rot:
		wheel_rot.rotation.y = rudder * 2.0
	if telegraph:
		telegraph.rotation.x = -throttle * 0.8
	var a = wrapf(GameData.wind_dir - heading, -PI, PI)
	for s in sail_pivots:
		var ang = signf(a) * lerpf(0.15, 1.3, sail_trim)
		s.node.rotation.y = ang if s.type == "main" else ang * 0.8
	if wake_node:
		var w = GameData.world
		var wy = (w.wave_h(pos2) if w else 0.0) + 0.1
		wake_node.global_transform = Transform3D(Basis(Vector3.UP, -heading), Vector3(pos2.x, wy, pos2.y))
		var sp = clampf(absf(speed) / 6.0, 0.0, 1.5)
		wake_node.scale = Vector3(sp, 1.0, sp)
		wake_node.visible = absf(speed) > 0.4
	if anchor_vis:
		anchor_vis.visible = anchor
	var night = GameData.time_h < 6.0 or GameData.time_h > 18.5
	for n in nav_nodes:
		n.visible = lights_on or night


func set_load_visuals(frac):
	if cargo_mm:
		cargo_mm.multimesh.visible_instance_count = int(cargo_total * clampf(frac, 0.0, 1.0))
	if pax_root:
		var n = pax_root.get_child_count()
		for i in range(n):
			pax_root.get_child(i).visible = i < int(n * clampf(frac, 0.0, 1.0)) if spec.pax > 0 else false


func can_moor():
	for i in range(GameData.PD.size()):
		var p = GameData.PD[i]
		var rel = pos2 - p.mid
		var side = signf(rel.dot(p.perp))
		var bp = GameData.berth_pos(i, spec, side)
		if pos2.distance_to(bp) < 45.0 + spec.L * 0.2 and absf(speed) < 1.5:
			return i
	return -1


func moor():
	var i = can_moor()
	if i < 0:
		return false
	var p = GameData.PD[i]
	var side = signf((pos2 - p.mid).dot(p.perp))
	if side == 0.0:
		side = 1.0
	moor_pos = GameData.berth_pos(i, spec, side)
	var h1 = GameData.berth_heading(i, 1.0)
	var h2 = GameData.berth_heading(i, -1.0)
	moor_head = h1 if absf(wrapf(h1 - heading, -PI, PI)) < absf(wrapf(h2 - heading, -PI, PI)) else h2
	moored = true
	moor_port = i
	anchor = false
	autopilot = 0
	return true


func moor_side():
	return signf((moor_pos - GameData.PD[moor_port].mid).dot(GameData.PD[moor_port].perp)) if moor_port >= 0 else 1.0


func cast_off():
	moored = false
	moor_port = -1


func _autopilot():
	if autopilot == 2:
		if route.is_empty():
			autopilot = 0
			if GameData.main:
				GameData.main.toast("Route complete - autopilot off. Take control for docking.")
			return
		var to = route[0] - pos2
		var last = route.size() == 1
		if to.length() < (40.0 if last else maxf(90.0, spec.L * 0.8)):
			route.pop_front()
			if last:
				autopilot = 0
				if GameData.main:
					GameData.main.toast("Arrived at berth approach - autopilot off")
			return
		ap_heading = atan2(to.x, -to.y)
	var e = wrapf(ap_heading - heading, -PI, PI)
	rudder = clampf(e * 1.6 - yawrate * 2.0, -1.0, 1.0)


func _ai(dt):
	moored = false
	if ai_wait > 0.0:
		ai_wait -= dt
		throttle = 0.0
		if ai_wait <= 0.0:
			_ai_next()
		return
	if route.is_empty():
		_ai_next()
		return
	var to = route[0] - pos2
	var d = to.length()
	var last = route.size() == 1
	if d < (30.0 if last else maxf(90.0, spec.L)):
		route.pop_front()
		if last:
			ai_wait = randf_range(30.0, 70.0)
		return
	var des = atan2(to.x, -to.y)
	var cap = 0.8
	for v in get_tree().get_nodes_in_group("vessels"):
		if v == self:
			continue
		var rel = v.pos2 - pos2
		var dd = rel.length()
		if dd < spec.L * 3.0 + 250.0:
			var ang = wrapf(atan2(rel.x, -rel.y) - heading, -PI, PI)
			if absf(ang) < 1.0:
				des += 0.7
				if dd < spec.L * 1.5 + 80.0 and absf(ang) < 0.6:
					cap = 0.0
	var dl = pos2.distance_to(route[route.size() - 1])
	if route.size() <= 2:
		cap = minf(cap, clampf(dl / (spec.L * 6.0 + 200.0), 0.07, 0.8))
	throttle = cap
	rudder = clampf(wrapf(des - heading, -PI, PI) * 1.8 - yawrate * 1.5, -1.0, 1.0)
	if spec.kind == "sail":
		sail_trim = ideal_trim()


func _ai_next():
	var from = GameData.nearest_port(pos2) if ai_port < 0 else ai_port
	var dest = randi() % GameData.PORTS.size()
	if dest == from:
		dest = (dest + 1) % GameData.PORTS.size()
	ai_port = dest
	route = GameData.route_to_port(pos2, dest, spec, 1.0)


func _remote(dt):
	if rtarget.is_empty():
		return
	var tp = Vector2(rtarget.x, rtarget.z)
	pos2 = pos2.lerp(tp + Vector2(sin(rtarget.h), -cos(rtarget.h)) * rtarget.v * 0.1, 1.0 - exp(-dt * 6.0))
	heading = lerp_angle(heading, rtarget.h, 1.0 - exp(-dt * 6.0))
	speed = rtarget.v
	vel2 = Vector2(sin(heading), -cos(heading)) * speed
	_pose(dt)
	_visuals(dt)
