extends Node
# Global state: ship specs, world layout, economy, navigation graph, save/load.

const VERSION = "1.0.0"
const UPDATE_REPO = "Tasin202/maritime-simulator"
const SAVE_PATH = "user://maritime_save.json"
const WORLD_HALF = 4200.0
const HULL_COLORS = [Color("f4f4f2"), Color("1d3557"), Color("b22222"), Color("2a6f4e"), Color("e9b44c"), Color("30343b"), Color("0b7fa8"), Color("7a4b8f")]
const INTERIOR_COLORS = [Color("5b4b3a"), Color("2f4858"), Color("6d2e46"), Color("3f5b3a")]
const WEATHER_NAMES = ["Clear", "Breezy", "Overcast", "Rain", "Storm", "Fog"]

const ISLANDS = [
	{"name": "Harbor Isle", "x": 0.0, "z": 0.0, "r": 380.0, "h": 60.0},
	{"name": "Coral Cay", "x": 1800.0, "z": -600.0, "r": 240.0, "h": 35.0},
	{"name": "Pine Island", "x": -1700.0, "z": 900.0, "r": 330.0, "h": 70.0},
	{"name": "Rocky Point", "x": 900.0, "z": 2000.0, "r": 450.0, "h": 90.0},
	{"name": "Sunset Isle", "x": -1200.0, "z": -1700.0, "r": 280.0, "h": 45.0},
	{"name": "Long Reach", "x": 2900.0, "z": 1400.0, "r": 520.0, "h": 80.0},
	{"name": "Gull Rock", "x": -2800.0, "z": -300.0, "r": 200.0, "h": 40.0},
	{"name": "Southgate", "x": -400.0, "z": 3000.0, "r": 380.0, "h": 55.0},
]
# ang = compass bearing (deg) from island centre towards the open sea where the pier points
const PORTS = [
	{"name": "Port Aurelia", "island": 0, "ang": 200.0, "yard": true, "tag": "Commercial port"},
	{"name": "Coral Cay Marina", "island": 1, "ang": 270.0, "yard": true, "tag": "Marina"},
	{"name": "Pinehaven", "island": 2, "ang": 70.0, "yard": true, "tag": "Ferry terminal"},
	{"name": "Rockport Cargo", "island": 3, "ang": 330.0, "yard": true, "tag": "Bulk terminal"},
	{"name": "Sunset Bay", "island": 4, "ang": 140.0, "yard": false, "tag": "Cruise terminal"},
	{"name": "Longreach Harbor", "island": 5, "ang": 270.0, "yard": true, "tag": "Container port"},
	{"name": "Gull Rock Dock", "island": 6, "ang": 90.0, "yard": false, "tag": "Fishing dock"},
	{"name": "Southgate Port", "island": 7, "ang": 20.0, "yard": false, "tag": "General cargo"},
]

var SHIPS = {}
var SHIP_ORDER = ["sloop", "schooner", "ferry", "cruise", "general", "bulk", "container"]
var PD = []
var nav_pts = []
var nav_adj = []

var world = null
var main = null
var active_ship = null

var money = 30000
var owned = []
var active_uid = -1
var next_uid = 1
var tx_log = []
var income_total = 0
var expense_total = 0
var contracts_done = 0
var time_h = 9.0
var weather = 0
var wind_dir = 0.8
var wind_speed = 6.0
var rain = 0.0
var settings = {"gfx": 0, "master": 0.8, "sfx": 0.9, "sens": 1.0, "hud": 1.0, "swap": false, "name": "Captain"}


func _ready():
	var S = func(id, nm, kind, L, B, dr, fr, price, vmax, acc, turn, fcap, frate, upk, pax, cargo, unit, radar, buy):
		SHIPS[id] = {"id": id, "name": nm, "kind": kind, "L": L, "B": B, "draft": dr, "free": fr, "price": price, "vmax": vmax, "acc": acc, "turn": turn, "fuelcap": fcap, "fuelrate": frate, "upkeep": upk, "pax": pax, "cargo": cargo, "unit": unit, "radar": radar, "buy": buy}
	S.call("sloop", "Aurora 36 Sloop", "sail", 11.0, 3.6, 1.8, 0.9, 22000, 7.0, 0.5, 28.0, 80.0, 0.012, 0.6, 4, 0, "", 3000.0, true)
	S.call("schooner", "Windrunner Schooner", "sail", 26.0, 6.0, 2.6, 1.4, 95000, 8.5, 0.4, 20.0, 400.0, 0.03, 2.0, 12, 0, "", 4000.0, true)
	S.call("ferry", "Seabird Ferry", "ferry", 48.0, 12.0, 2.2, 3.0, 380000, 13.0, 0.9, 14.0, 5000.0, 0.9, 6.0, 150, 0, "", 6000.0, true)
	S.call("cruise", "Odyssey Cruise Liner", "cruise", 190.0, 30.0, 7.0, 9.0, 2400000, 11.0, 0.25, 5.0, 200000.0, 8.0, 40.0, 800, 0, "", 8000.0, true)
	S.call("general", "Coastal Freighter", "general", 90.0, 15.0, 5.0, 4.0, 600000, 9.0, 0.3, 7.0, 30000.0, 1.5, 12.0, 0, 800, "t", 6000.0, true)
	S.call("bulk", "Ironbark Bulk Carrier", "bulk", 180.0, 28.0, 10.0, 7.0, 900000, 8.5, 0.18, 4.0, 120000.0, 3.5, 25.0, 0, 2500, "t", 8000.0, true)
	S.call("container", "Meridian Container Ship", "container", 230.0, 32.0, 11.0, 10.0, 1600000, 11.0, 0.2, 4.0, 250000.0, 5.0, 35.0, 0, 600, "TEU", 8000.0, true)
	S.call("trawler", "Fishing Trawler", "fishing", 24.0, 6.5, 2.2, 1.6, 0, 6.0, 0.6, 18.0, 2000.0, 0.2, 1.0, 0, 0, "", 3000.0, false)
	_compute_ports()
	build_nav()


func _compute_ports():
	PD.clear()
	for p in PORTS:
		var isl = ISLANDS[p.island]
		var c = Vector2(isl.x, isl.z)
		var a = deg_to_rad(p.ang)
		var dir = Vector2(sin(a), -cos(a))
		var quay = c + dir * (isl.r * 0.78)
		var ps = quay + dir * 25.0
		var pe = ps + dir * 320.0
		var mid = (ps + pe) * 0.5
		PD.append({"quay": quay, "dir": dir, "perp": Vector2(-dir.y, dir.x), "mid": mid, "pier_end": pe, "approach": mid + dir * 520.0, "yaw": a})


func berth_pos(pi, spec, side):
	var d = PD[pi]
	return d.mid + d.perp * side * (7.0 + 2.5 + spec.B * 0.5)


func berth_heading(pi, hs):
	var v = PD[pi].dir * hs
	return atan2(v.x, -v.y)


func make_interact(parent, pos, label, action):
	var n = Node3D.new()
	n.position = pos
	n.set_meta("label", label)
	n.set_meta("action", action)
	n.add_to_group("interact")
	parent.add_child(n)
	return n


func depth_at(p):
	var d = 400.0
	for isl in ISLANDS:
		var dd = p.distance_to(Vector2(isl.x, isl.z)) - isl.r
		d = min(d, max(0.5, 2.0 + dd * 0.1))
	return d


func nearest_port(p):
	var best = 0
	for i in range(PD.size()):
		if PD[i].mid.distance_to(p) < PD[best].mid.distance_to(p):
			best = i
	return best


func reward_rate(spec):
	match spec.kind:
		"sail": return 132.0
		"ferry": return 22.0
		"cruise": return 40.0
		"general": return 9.0
		"bulk": return 4.0
		"container": return 14.0
	return 5.0


func make_contracts(pi, spec):
	var out = []
	var rng = RandomNumberGenerator.new()
	rng.seed = hash([pi, int(time_h / 4.0), spec.id])
	for k in range(5):
		var dest = rng.randi() % PORTS.size()
		if dest == pi:
			dest = (dest + 1) % PORTS.size()
		var km = PD[pi].mid.distance_to(PD[dest].mid) / 1000.0
		var cap = spec.pax if spec.pax > 0 else spec.cargo
		var amt = max(1, int(cap * rng.randf_range(0.5, 1.0)))
		out.append({"from": pi, "to": dest, "amount": amt, "reward": int(km * amt * reward_rate(spec) * rng.randf_range(0.9, 1.25)), "pax": spec.pax > 0})
	return out


func add_money(a, why):
	money += int(a)
	income_total += int(a)
	tx_log.push_front({"t": time_h, "txt": why, "amt": int(a)})
	if tx_log.size() > 40:
		tx_log.pop_back()


func spend(a, why):
	a = int(a)
	if money < a:
		return false
	money -= a
	expense_total += a
	tx_log.push_front({"t": time_h, "txt": why, "amt": -a})
	if tx_log.size() > 40:
		tx_log.pop_back()
	return true


func upg_cost(spec, lvl):
	return int(spec.price * 0.02 * (lvl + 1))


# ---------------- navigation graph ----------------
func seg_clear(a, b, margin):
	for isl in ISLANDS:
		var c = Vector2(isl.x, isl.z)
		if Geometry2D.get_closest_point_to_segment(c, a, b).distance_to(c) < isl.r + margin:
			return false
	return true


func build_nav():
	nav_pts.clear()
	nav_adj.clear()
	var step = 450.0
	var n = int(3600.0 / step)
	for i in range(-n, n + 1):
		for j in range(-n, n + 1):
			var p = Vector2(i * step, j * step)
			var ok = true
			for isl in ISLANDS:
				if p.distance_to(Vector2(isl.x, isl.z)) < isl.r + 260.0:
					ok = false
			if ok:
				nav_pts.append(p)
	for i in range(nav_pts.size()):
		nav_adj.append([])
	for i in range(nav_pts.size()):
		for j in range(i + 1, nav_pts.size()):
			if nav_pts[i].distance_to(nav_pts[j]) < step * 1.5 and seg_clear(nav_pts[i], nav_pts[j], 230.0):
				nav_adj[i].append(j)
				nav_adj[j].append(i)


func find_path(a, b):
	if seg_clear(a, b, 200.0):
		return [b]
	var n = nav_pts.size()
	var dist = []
	var prev = []
	var done = []
	for i in range(n + 2):
		dist.append(1e18)
		prev.append(-1)
		done.append(false)
	var S = n
	var E = n + 1
	var sadj = []
	var eadj = []
	for i in range(n):
		var p = nav_pts[i]
		if p.distance_to(a) < 1500.0 and seg_clear(a, p, 200.0):
			sadj.append(i)
		if p.distance_to(b) < 1500.0 and seg_clear(b, p, 200.0):
			eadj.append(i)
	dist[S] = 0.0
	var open = [S]
	while not open.is_empty():
		var bi = 0
		for k in range(open.size()):
			if dist[open[k]] < dist[open[bi]]:
				bi = k
		var u = open[bi]
		open.remove_at(bi)
		if done[u]:
			continue
		done[u] = true
		if u == E:
			break
		var nb = []
		if u == S:
			nb = sadj
		elif u < n:
			nb = nav_adj[u].duplicate()
			if eadj.has(u):
				nb.append(E)
		for v in nb:
			var pu = a if u == S else nav_pts[u]
			var pv = b if v == E else nav_pts[v]
			var nd = dist[u] + pu.distance_to(pv)
			if nd < dist[v]:
				dist[v] = nd
				prev[v] = u
				open.append(v)
	if prev[E] == -1:
		return [b]
	var path = []
	var cur = E
	while cur != S and cur != -1:
		path.push_front(b if cur == E else nav_pts[cur])
		cur = prev[cur]
	return path


func route_to_port(from, pi, spec, side):
	var path = find_path(from, PD[pi].approach)
	path.append(berth_pos(pi, spec, side))
	return path


# ---------------- save / load ----------------
func new_game():
	money = 30000
	owned = []
	active_uid = -1
	next_uid = 1
	tx_log = []
	income_total = 0
	expense_total = 0
	contracts_done = 0
	time_h = 9.0


func save_game():
	var d = {"money": money, "owned": owned, "active": active_uid, "next": next_uid, "tx": tx_log, "inc": income_total, "exp": expense_total, "done": contracts_done, "time": time_h, "weather": weather, "settings": settings, "player": main.player_save() if main else {}}
	var f = FileAccess.open(SAVE_PATH + ".tmp", FileAccess.WRITE)
	if f == null:
		return false
	f.store_string(JSON.stringify(d))
	f.close()
	var da = DirAccess.open("user://")
	if da:
		if da.file_exists("maritime_save.json"):
			da.remove("maritime_save.json")
		da.rename("maritime_save.json.tmp", "maritime_save.json")
	return true


func has_save():
	return FileAccess.file_exists(SAVE_PATH)


func load_game():
	if not has_save():
		return {}
	var f = FileAccess.open(SAVE_PATH, FileAccess.READ)
	if f == null:
		return {}
	var d = JSON.parse_string(f.get_as_text())
	f.close()
	if typeof(d) != TYPE_DICTIONARY:
		return {}
	money = int(d.get("money", 30000))
	owned = d.get("owned", [])
	active_uid = int(d.get("active", -1))
	next_uid = int(d.get("next", 1))
	tx_log = d.get("tx", [])
	income_total = int(d.get("inc", 0))
	expense_total = int(d.get("exp", 0))
	contracts_done = int(d.get("done", 0))
	time_h = float(d.get("time", 9.0))
	weather = int(d.get("weather", 0))
	var st = d.get("settings", {})
	for k in st:
		settings[k] = st[k]
	return d.get("player", {})
